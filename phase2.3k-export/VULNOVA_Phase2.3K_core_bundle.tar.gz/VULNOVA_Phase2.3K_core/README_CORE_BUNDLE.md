# VULNOVA Phase 2.3K — core bundle (readers' edition)

Everything needed to **read and audit the decision**, without the bulk.

## Included
report · all five CSV deliverables · quality summary · integrity manifest · inventory method
and manifest · the 21-cutoff list · evidence (census index, EPSS availability) · KEV timeline
(revisions, membership-by-revision, first-seen) · all builder and verifier tools ·
`risk_set_membership/INDEX.csv` + the partition scheme description.

## Deliberately NOT included
| Absent | Size | Why |
|---|---:|---|
| `risk_set_membership/cutoff_*.csv.gz` (21) | 18 MB | the full per-record membership dataset; per-cutoff sizes and SHA-256 are in `INDEX.csv` |
| `inventory/inventory_ids/` | ~16 MB | per-cutoff identifier lists |
| staged census fact files | 406 MB | regenerate in ~47 s each from the revisions pinned in `cvelistv5_inventory_manifest.csv` |

## Consequence you must know
`phase2_3k_integrity_manifest.json` covers 45 files **including** the 21 membership partitions
and the identifier lists. Those are not here, so verifying the manifest against this bundle will
report them missing. That is expected, not corruption. To verify the full set, use
`VULNOVA_Phase2.3K_export.tar.gz` (21,439,355 B,
sha256 `26a2a144da3d44e37308d4f5cfdc3b02e3c2899a9e37b9664a64d3d98183bb7d`), which contains them.

## Verify what IS here
```
cd VULNOVA_Phase2.3K_core
python3 -c "
import json, hashlib, os
man = json.load(open('phase2_3k_integrity_manifest.json'))
present = [e for e in man['files'] if os.path.isfile(e['path'])]
absent  = [e['path'] for e in man['files'] if not os.path.isfile(e['path'])]
bad = [e['path'] for e in present
       if hashlib.sha256(open(e['path'],'rb').read()).hexdigest() != e['sha256']]
print(f'{len(present)} present, {len(bad)} mismatched, {len(absent)} absent (expected: the bulk)')
print('mismatched:', bad)"
```
