#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - exact per-record census of one pinned cvelistV5 revision.

Per-object fetching is the bottleneck for this repository. Measured on this sandbox:

    git cat-file (blobless lazy fetch)   ~0.75 s per record   -> 279,720 records = ~58 hours
    git checkout (batched in theory)     ~0.71 s per record   -> no better, git does not batch
    GitHub blob API                      ~0.28 s per record   -> ~22 hours
    codeload tarball, streamed           ~4.7 MB/s, ONE request -> the only viable route

So a single archive request is used. Because the stream is parseable in flight, the records are
never written to disk: each member is read, reduced to the facts Phase 2.3K needs, and discarded.
That keeps a ~2 GB unpacked tree out of the workspace entirely.

Completeness: the member count of the archive is compared against the record count obtained from
`git ls-tree -r` at the same revision. The two are independent routes to the same set, so any
truncation, partial download or path-filtering error shows up as a mismatch.

Usage: curl -sSL <codeload-url> | census_from_tarball.py <cutoff> <expected_count> <out.jsonl.gz>
"""

from __future__ import annotations

import gzip
import hashlib
import json
import re
import sys
import tarfile

RECORD_RE = re.compile(r"cves/(\d{4})/(\d+)xxx/(CVE-\d{4}-\d+)\.json$")
CVSS_KEYS = ("cvssV4_0", "cvssV3_1", "cvssV3_0", "cvssV2_0")


def facts_from_record(cve_id, raw):
    try:
        doc = json.loads(raw)
    except ValueError as exc:
        return {"cve_id": cve_id, "present": True, "parse_error": str(exc),
                "record_sha256": hashlib.sha256(raw).hexdigest(), "record_bytes": len(raw)}
    meta = doc.get("cveMetadata", {}) or {}
    containers = doc.get("containers") or {}
    cna = containers.get("cna") or {}
    best = None
    for metric in cna.get("metrics", []) or []:
        for key in CVSS_KEYS:
            val = metric.get(key)
            if isinstance(val, dict) and val.get("baseScore") is not None:
                if best is None or CVSS_KEYS.index(key) < CVSS_KEYS.index(best[0]):
                    best = (key, val.get("baseScore"), val.get("baseSeverity"),
                            val.get("source") or val.get("type") or "")
    adp_best = None
    for adp in containers.get("adp") or []:
        for metric in adp.get("metrics", []) or []:
            for key in CVSS_KEYS:
                val = metric.get(key)
                if isinstance(val, dict) and val.get("baseScore") is not None:
                    if adp_best is None or CVSS_KEYS.index(key) < CVSS_KEYS.index(adp_best[0]):
                        adp_best = (key, val.get("baseScore"), val.get("baseSeverity"),
                                    val.get("source") or val.get("type") or "")
    descriptions = cna.get("descriptions") or []
    desc = descriptions[0].get("value", "") if (descriptions and
                                                isinstance(descriptions[0], dict)) else ""
    return {
        "cve_id": cve_id,
        "present": True,
        "rejected": "** REJECT **" in desc,
        "state": meta.get("state", ""),
        "date_published": meta.get("datePublished", ""),
        "date_updated": meta.get("dateUpdated", ""),
        "date_reserved": meta.get("dateReserved", ""),
        "assigner": meta.get("assignerShortName", ""),
        "record_sha256": hashlib.sha256(raw).hexdigest(),
        "record_bytes": len(raw),
        "has_cvss": best is not None or adp_best is not None,
        "cvss_cna": best is not None,
        "cvss_adp_only": best is None and adp_best is not None,
        "cvss_version": (best or adp_best)[0] if (best or adp_best) else "",
        "cvss_score": (best or adp_best)[1] if (best or adp_best) else "",
        "cvss_severity": (best or adp_best)[2] if (best or adp_best) else "",
        "cvss_source": (best or adp_best)[3] if (best or adp_best) else "",
        "cvss_from_adp": best is None and adp_best is not None,
    }


def main() -> int:
    if len(sys.argv) != 4:
        sys.stderr.write("usage: census_from_tarball.py <cutoff> <expected_count> <out.jsonl.gz>\n")
        return 2
    cutoff, expected, outpath = sys.argv[1], int(sys.argv[2]), sys.argv[3]

    seen, n_records, n_members, n_other, n_parse_errors = set(), 0, 0, 0, 0
    with gzip.GzipFile(filename="", fileobj=open(outpath, "wb"), mode="wb", mtime=0) as out:
        with tarfile.open(fileobj=sys.stdin.buffer, mode="r|gz") as tar:
            for member in tar:
                n_members += 1
                if not member.isfile():
                    continue
                m = RECORD_RE.search(member.name)
                if not m:
                    n_other += 1
                    continue
                cve_id = m.group(3)
                fh = tar.extractfile(member)
                raw = fh.read() if fh else b""
                rec = facts_from_record(cve_id, raw)
                rec["cutoff_T"] = cutoff
                if "parse_error" in rec:
                    n_parse_errors += 1
                seen.add(cve_id)
                n_records += 1
                out.write((json.dumps(rec, sort_keys=True) + "\n").encode("utf-8"))
                if n_records % 50000 == 0:
                    sys.stderr.write("    %d records...\n" % n_records)
                    sys.stderr.flush()

    summary = {
        "cutoff_T": cutoff,
        "archive_members": n_members,
        "record_members": n_records,
        "distinct_cve_ids": len(seen),
        "non_record_members": n_other,
        "parse_errors": n_parse_errors,
        "expected_from_ls_tree": expected,
        "completeness_match": n_records == expected,
        "duplicate_ids": n_records - len(seen),
    }
    sys.stderr.write(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    with open(outpath + ".summary.json", "w", encoding="utf-8") as fh:
        fh.write(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return 0 if summary["completeness_match"] and summary["duplicate_ids"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
