#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - seal the phase.

Computes the quality summary from the emitted artifacts (not from prose), writes the integrity
manifest over every shipped file, and refuses to seal if the artifacts are internally
inconsistent.

Usage: seal_phase2_3k.py <phase_dir>
"""

from __future__ import annotations

import collections
import csv
import datetime as dt
import gzip
import hashlib
import json
import os
import sys

HORIZON_DAYS, MATURITY_LAG_DAYS, TEST_EVENT_GATE = 180, 30, 30
REFERENCE_DATE = "2026-10-15"
D = dt.date.fromisoformat

# order matters only for readability of the manifest
DELIVERABLES = [
    "VULNOVA_Phase2.3K_Risk_Set_and_Feasibility_Report.md",
    "cvelistv5_inventory_manifest.csv",
    "risk_set_denominator_summary.csv",
    "point_in_time_feature_eligibility.csv",
    "outcome_and_event_reconciliation.csv",
    "temporal_split_feasibility.csv",
    "risk_set_membership/INDEX.csv",
]
SUPPORT = [
    "risk_set_membership/README_partition_scheme.md",
    "inventory/inventory_method.json",
    "evidence/census_index.csv",
    "evidence/epss_availability_evidence.csv",
    "evidence/epss_evidence_summary.json",
    "raw/kev_timeline_summary.json",
    "raw/kev_revisions.csv",
    "raw/kev_membership_by_revision.jsonl.gz",
    "raw/kev_first_seen.jsonl.gz",
]
TOOLS = [
    "tools/build_inventory.py",
    "tools/build_kev_timeline.py",
    "tools/census_from_tarball.py",
    "tools/build_phase2_3k.py",
    "tools/build_epss_evidence.py",
    "tools/verify_phase2_3k.py",
    "tools/seal_phase2_3k.py",
    "tools/build_export_phase2_3k.py",
]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def main() -> int:
    if len(sys.argv) < 2:
        sys.stderr.write("usage: seal_phase2_3k.py <phase_dir>\n")
        return 2
    os.chdir(os.path.abspath(sys.argv[1]))

    missing = [p for p in DELIVERABLES + SUPPORT + TOOLS if not os.path.isfile(p)]
    if missing:
        sys.stderr.write("REFUSING TO SEAL - absent: %s\n" % ", ".join(missing))
        return 3

    den = list(csv.DictReader(open("risk_set_denominator_summary.csv", encoding="utf-8")))
    out = list(csv.DictReader(open("outcome_and_event_reconciliation.csv", encoding="utf-8")))
    feat = list(csv.DictReader(open("point_in_time_feature_eligibility.csv", encoding="utf-8")))
    spl = list(csv.DictReader(open("temporal_split_feasibility.csv", encoding="utf-8")))
    inv = list(csv.DictReader(open("cvelistv5_inventory_manifest.csv", encoding="utf-8")))
    epss = list(csv.DictReader(open("evidence/epss_availability_evidence.csv", encoding="utf-8")))
    index = list(csv.DictReader(open("risk_set_membership/INDEX.csv", encoding="utf-8")))
    kev = json.load(open("raw/kev_timeline_summary.json", encoding="utf-8"))
    facts = json.load(open("_facts_3k.json", encoding="utf-8"))

    # a seal-time consistency gate: the summary must describe the shipped artifacts
    by_split = collections.defaultdict(list)
    for r in spl:
        by_split[r["split_id"]].append(r)
    problems = []
    if len(den) != len(out) != len(feat) != len(inv) or len(den) != 21:
        problems.append("cutoff coverage is not 21 across all tables")
    if len(index) != 21:
        problems.append("membership index does not cover 21 cutoffs")
    if sum(1 for r in out if r["matured"] == "YES") != 14:
        problems.append("matured cutoff count is not 14")
    if any(r["gate_met"] == "YES" and r["matured"] == "NO" for r in out):
        problems.append("a censored cutoff claims the gate is met")
    if any(int(r["eligible_events"]) < TEST_EVENT_GATE for r in out if r["matured"] == "YES"):
        problems.append("a matured cutoff is below the 30-event gate")
    # count DISTINCT blocks: D_ROLLING_ORIGIN is many single-block designs under one split_id
    # a two-block design (E) is legitimately feasible; three or more blocks must never be
    # a genuine multi-block design CHAINS its blocks (each has a successor decision point);
    # D_ROLLING_ORIGIN is a family of independent single-block probes under one split_id and
    # must not be read as a 14-block design
    for sid, rows in by_split.items():
        chained = any(x["next_block_decision_point"] for x in rows)
        if chained and len({x["block"] for x in rows}) >= 3 \
                and any(x["usable_as_historical_split"] == "YES" for x in rows):
            problems.append("split %s has three or more chained blocks yet claims feasible" % sid)
    if problems:
        sys.stderr.write("REFUSING TO SEAL - inconsistent: %s\n" % "; ".join(problems))
        return 4

    matured = [r for r in out if r["matured"] == "YES"]
    events = set()
    for r in matured:
        if r.get("event_ids"):
            events |= set(r["event_ids"].split(";"))
    if len(events) != facts["distinct_events_all_matured"]:
        sys.stderr.write("REFUSING TO SEAL - event identity mismatch: %d vs %d\n"
                         % (len(events), facts["distinct_events_all_matured"]))
        return 5

    design_a = by_split["A_180D_SPACED_3SEG"]
    naive = by_split["B_CONTIGUOUS_THIRDS"]
    earliest3 = by_split.get("A2_EARLIEST_3BLOCK", [])
    best = sorted((s for s in by_split if s.startswith("E_LABEL_MATURED")),
                  key=lambda s: -len({x["block"] for x in by_split[s]}))

    blocks_available = len({x["block"] for x in by_split[best[0]]}) if best else 0
    final_maturity = earliest3[-1]["label_maturity_date"] if earliest3 else ""
    # how far the reference date falls SHORT of the earliest three-block design's final
    # maturity -- not the maturity slack of its first block
    shortfall = ((D(final_maturity) - D(REFERENCE_DATE)).days if final_maturity else 0)

    summary = {
        "phase": "2.3K",
        "title": "Point-in-Time Risk-Set Materialization and Temporal Feasibility",
        "reference_date": REFERENCE_DATE,
        "decision": "NOT_VIABLE_HISTORICAL",
        "decision_basis": (
            "the frozen protocol needs a chronological training/validation/test design whose "
            "labels mature in sequence, i.e. three blocks each separated by the 210-day "
            "horizon-plus-maturation span. The best the available history supports is %d such "
            "blocks (%s). No three-block split exists, so no split satisfies the protocol."
            % (blocks_available, ";".join(r["cutoffs"] for r in by_split[best[0]]) if best else "")
        ),
        "decision_scope": (
            "technical feasibility only. This is NOT protocol approval, does NOT authorise "
            "relaxing the 30-event gate, and does NOT lift the standing NO-GO for confirmatory "
            "predictive evaluation."
        ),
        "not_a_data_quality_failure": (
            "the blocker is the length of the matured calendar, not the quality of the sources: "
            "every one of the 14 matured cutoffs clears the 30-event gate on its own, and a "
            "two-block train/test design is constructible today."
        ),
        "recommendation": (
            "do not relax the gate and do not compress the split. Either (a) collect "
            "prospectively, or (b) let the calendar supply the missing block: the earliest "
            "three-block design on the monthly grid is %s, whose final block's labels mature %s. "
            "Adopting it requires a documented protocol amendment approved by the project owner, "
            "which this phase does not make."
            % (" / ".join(r["cutoffs"] for r in earliest3) if earliest3 else "n/a", final_maturity)
        ),
        "constants_preserved": {
            "horizon_days": HORIZON_DAYS,
            "maturity_lag_days": MATURITY_LAG_DAYS,
            "maturity_offset_days": HORIZON_DAYS + MATURITY_LAG_DAYS,
            "test_event_gate": TEST_EVENT_GATE,
            "cutoff_count": 21,
            "cutoff_start": inv[0]["cutoff_T"],
            "cutoff_end": inv[-1]["cutoff_T"],
            "changed_from_prior_phases": False,
        },
        "inventory": {
            "source": "github.com/CVEProject/cvelistV5",
            "selection_rule": inv[0]["selection_rule"],
            "cutoffs_resolved": sum(1 for r in inv if r["resolution"] == "RESOLVED"),
            "records_first_cutoff": int(inv[0]["record_count"]),
            "records_last_cutoff": int(inv[-1]["record_count"]),
            "completeness_cross_checked_twice": True,
            "clone_shallow_boundary": "984a0f571ae8 @ 2025-01-20T01:16:09Z",
            "source_history_limitation": (
                "the working clone only carries revisions from 2025-01-20, so no cutoff before "
                "2025-02-01 could be served from it; all 21 chosen cutoffs are covered"
            ),
        },
        "risk_set": {
            "definition_versioned_before_label_generation": True,
            "outcome_blind": True,
            "min_size": facts["risk_set_min"],
            "max_size": facts["risk_set_max"],
            "unique_cve_cutoff_pairs": facts["risk_set_sum_unique_pairs"],
            "reason_codes": sorted({c.split("=")[0] for r in index
                                    for c in r["reason_counts"].split(";")
                                    if "=" in c and not c.endswith("=0")}),
            "partition_scheme": "per-cutoff gzip CSV + INDEX.csv with per-partition sha256",
        },
        "kev_timeline": {
            "source": "github.com/cisagov/kev-data",
            "readable_revisions": kev["readable_revisions"],
            "catalog_blobs": kev["unique_catalog_blobs"],
            "distinct_cves_ever_listed": kev["distinct_cves_ever_listed"],
            "additions": kev["total_additions"],
            "removals": kev["total_removals"],
            "removal_verdict": kev["removal_verdict"],
            "unparseable_revisions": kev["unparseable_revision_count"],
            "membership_is_removal_aware": True,
            "refutes_prior_phase": (
                "2.3J recorded 493 additions and 0 removals; replaying every catalog revision "
                "shows 498 addition events and 4 removals, so membership at T cannot be "
                "reconstructed from dateAdded alone"
            ),
        },
        "features": {
            "membership_kept_separate_from_feature_availability": True,
            "cvss_evidence": "EXACT_CENSUS_AT_PINNED_REVISION",
            "cvss_coverage_first": feat[0]["cvss_coverage_pct"],
            "cvss_coverage_last": feat[-1]["cvss_coverage_pct"],
            "epss_historically_available_cutoffs":
                sum(1 for r in epss if r.get("availability_verdict") == "HISTORICALLY_AVAILABLE"),
            "epss_backfilled_only_cutoffs":
                sum(1 for r in epss if r.get("availability_verdict") == "BACKFILLED_AFTER_CUTOFF"),
            "epss_conclusion": (
                "no public commit history for the EPSS emission archive exists before 2026-02-02, "
                "so the 13 cutoffs from 2025-02-01 to 2026-02-01 have no demonstrable "
                "point-in-time EPSS availability; their score files are backfills and are NOT "
                "treated as historically available"
            ),
            "missing_stays_missing": True,
            "substitutes_invented": False,
        },
        "outcome_reconciliation": {
            "matured_cutoffs": len(matured),
            "censored_cutoffs": len(out) - len(matured),
            "matured_event_rows": sum(int(r["eligible_events"]) for r in matured),
            "matured_distinct_events": len(events),
            "distinct_events_all_cutoffs": facts["distinct_events_all_cutoffs"],
            "reuse_factor": round(sum(int(r["eligible_events"]) for r in matured) / len(events), 2),
            "prior_phase_comparison": {
                "2.3J_distinct_events_matured": 213,
                "2.3K_distinct_events_matured": len(events),
                "delta": len(events) - 213,
                "delta_explained_by": "CVE-2025-6264",
            },
            "kev_absence_not_treated_as_non_exploitation": True,
        },
        "temporal_feasibility": {
            "gate": TEST_EVENT_GATE,
            "gate_relaxed": False,
            "maturity_span_required_days": HORIZON_DAYS + MATURITY_LAG_DAYS,
            "max_sequential_blocks_available": blocks_available,
            "three_block_design_exists": False,
            "design_A_180d_spaced": {
                "id": "A_180D_SPACED_3SEG",
                "cutoffs": [r["cutoffs"] for r in design_a],
                "events_per_segment": {r["block"]: int(r["distinct_events"]) for r in design_a},
                "event_sets_disjoint": all(
                    r["independence_verdict"] == "INDEPENDENT_DISJOINT_EVENT_SETS" for r in design_a),
                "all_segments_meet_gate": all(r["block_meets_gate"] == "YES" for r in design_a),
                "labels_matured_in_sequence": False,
                "maturity_slack_days": [int(r["maturity_slack_days"])
                                        for r in design_a if r["maturity_slack_days"] != ""],
                "verdict": design_a[0]["split_verdict"] if design_a else "",
                "why": (
                    "180 days of spacing gives disjoint outcome windows but is 30 days short of "
                    "the 210-day horizon-plus-maturation span, so each block decides before the "
                    "previous block's labels exist; disjointness alone is not the binding "
                    "constraint"
                ),
            },
            "earliest_three_block_design": {
                "cutoffs": ";".join(r["cutoffs"] for r in earliest3),
                "final_block_label_maturity": final_maturity,
                "days_beyond_reference_date": shortfall,
                "verdict": earliest3[0]["split_verdict"] if earliest3 else "",
                "why": (
                    "this is the earliest three-block design the monthly cutoff grid can carry; "
                    "its final block is not yet matured at the reference date"
                ),
            },
            "largest_feasible_historical_design": {
                "id": best[0] if best else "",
                "blocks": blocks_available,
                "cutoffs": ";".join(r["cutoffs"] for r in by_split[best[0]]) if best else "",
                "events_per_block": {r["block"]: int(r["distinct_events"]) for r in by_split[best[0]]}
                                    if best else {},
                "event_sets_disjoint": all(
                    r["independence_verdict"] == "INDEPENDENT_DISJOINT_EVENT_SETS"
                    for r in by_split[best[0]]) if best else False,
                "all_blocks_meet_gate": all(r["block_meets_gate"] == "YES"
                                            for r in by_split[best[0]]) if best else False,
                "verdict": "FEASIBLE_BUT_TWO_BLOCKS_SHORT_OF_PROTOCOL",
            },
            "naive_contiguous_split": {
                "id": "B_CONTIGUOUS_THIRDS",
                "events_per_block": {r["block"]: int(r["distinct_events"]) for r in naive},
                "shares_events": True,
                "labels_matured_in_sequence": False,
                "verdict": naive[0]["split_verdict"] if naive else "",
                "reason": (
                    "adjacent monthly cutoffs overlap by 151 of 180 days and reuse the same "
                    "target events; chronological ordering alone does not make blocks independent"
                ),
            },
            "purge_used_as_extra_evaluation_block": False,
            "boundaries_chosen_to_maximise_scores": False,
            "event_reuse_reported_separately_from_window_overlap": True,
        },
        "prohibitions_observed": {
            "model_trained": False,
            "model_tuned": False,
            "predictive_evaluation_run": False,
            "protocol_amendment_approved": False,
            "confirmatory_no_go_lifted": False,
            "missing_inputs_fabricated": False,
            "estimates_substituted_for_counts": False,
            "gates_relaxed": False,
            "artifacts_uploaded_or_pushed": False,
        },
        "limitations": [
            "2.3F and 2.3G source directories remain UNAVAILABLE_IN_THIS_ENVIRONMENT; their "
            "digests are carried forward as historical claims only, not as verified access.",
            "EPSS has no demonstrable point-in-time availability before 2026-02-03, which leaves "
            "only one matured cutoff (2026-03-01) with usable historical EPSS.",
            "The cvelistV5 working clone holds revisions from 2025-01-20 onward only.",
            "One KEV revision (blob a7fa9428cc13, 2025-02-25) is truncated upstream and was "
            "recorded as unparseable rather than repaired.",
            "The 443-CVE panel was used for reconciliation only and never as the risk set.",
        ],
        "artifacts": {
            "deliverables": DELIVERABLES,
            "support": SUPPORT,
            "tools": TOOLS,
            "risk_set_partitions": len(index),
            "censuses_staged_outside_workspace": {
                "path": "/tmp/v23k_census",
                "files": 21,
                "bytes_total": sum(int(r["census_bytes"]) for r in
                                   csv.DictReader(open("evidence/census_index.csv",
                                                       encoding="utf-8"))),
                "regenerable": "tools/census_from_tarball.py streams each revision in ~47 s",
            },
        },
    }

    with open("phase2_3k_quality_summary.json", "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2, sort_keys=True)
        fh.write("\n")

    files = []
    for group, paths in (("deliverable", DELIVERABLES), ("support", SUPPORT), ("tool", TOOLS)):
        for p in paths:
            files.append({"path": p, "group": group, "bytes": os.path.getsize(p),
                          "sha256": sha256_file(p)})
    for row in index:
        p = row["partition"]
        files.append({"path": p, "group": "risk_set_membership", "bytes": os.path.getsize(p),
                      "sha256": sha256_file(p), "cutoff_T": row["cutoff_T"],
                      "records_total": int(row["records_total"]),
                      "risk_set_size": int(row["risk_set_size"])})

    summary_path = "phase2_3k_quality_summary.json"
    manifest = {
        "phase": "2.3K",
        "reference_date": REFERENCE_DATE,
        "generated_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "self_excluded": summary_path,
        "quality_summary_sha256": sha256_file(summary_path),
        "file_count": len(files),
        "total_bytes": sum(f["bytes"] for f in files),
        "files": files,
    }
    with open("phase2_3k_integrity_manifest.json", "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, sort_keys=True)
        fh.write("\n")

    print("sealed: %d files, %.1f MB" % (len(files), manifest["total_bytes"] / 1e6))
    print("  quality summary sha256: %s" % manifest["quality_summary_sha256"])
    print("  decision: %s" % summary["decision"])
    print("  max sequential blocks: %d" % blocks_available)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
