#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - historical cvelistV5 record inventory at each prediction cutoff.

Enumerates the *complete* set of CVE records present in the official CVEProject/cvelistV5
repository at one pinned revision per cutoff, using a blobless partial clone.

Completeness argument: the enumeration runs against the local object database at a specific
commit SHA, so it cannot be silently truncated the way a single paginated API response can. For
each cutoff the resolver also re-reads every year subtree SHA, and the resulting record count is
cross-checked against the same revision queried through the GitHub tree API (which is where the
sizes of the API's own limits were measured in the first place).

Timestamp-selection rule (documented, applied uniformly):
    R(T) = the commit with the greatest committer timestamp <= T 00:00:00 UTC on branch main.
Committer time is used rather than author time because it is the time the revision entered the
published branch.

Usage: build_inventory.py <cvelist_clone_dir> <cutoffs_file> <outdir>
"""

from __future__ import annotations

import csv
import gzip
import json
import os
import re
import subprocess
import sys

RECORD_RE = re.compile(r"^cves/(\d{4})/(\d+)xxx/(CVE-\d{4}-\d+)\.json$")


def git(repo, *args):
    return subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True,
                          check=True).stdout


def resolve(repo, cutoff):
    sha = git(repo, "rev-list", "-1", "--before=%sT00:00:00Z" % cutoff, "HEAD").strip()
    if not sha:
        return None
    iso = git(repo, "log", "-1", "--format=%cI", sha).strip()
    return sha, iso


def enumerate_revision(repo, sha):
    """Every path under cves/ at the revision, plus the per-year subtree SHAs."""
    raw = git(repo, "ls-tree", "-r", "--name-only", sha, "--", "cves/").splitlines()
    ids, by_year, nonconforming = [], {}, []
    for path in raw:
        m = RECORD_RE.match(path)
        if m:
            ids.append(m.group(3))
            by_year[m.group(1)] = by_year.get(m.group(1), 0) + 1
        else:
            nonconforming.append(path)
    ids.sort()
    cves_tree = git(repo, "rev-parse", "%s:cves" % sha).strip()
    year_trees = {}
    for line in git(repo, "ls-tree", sha, "--", "cves/").splitlines():
        meta, name = line.split("\t", 1)
        mode, otype, osha = meta.split()
        if otype == "tree" and name.startswith("cves/"):
            year_trees[name.split("/", 1)[1]] = osha
    return ids, by_year, nonconforming, cves_tree, year_trees


def main() -> int:
    if len(sys.argv) != 4:
        sys.stderr.write("usage: build_inventory.py <clone_dir> <cutoffs_file> <outdir>\n")
        return 2
    repo = os.path.abspath(sys.argv[1])
    cutoffs = [l.strip() for l in open(sys.argv[2]) if l.strip() and not l.startswith("#")]
    outdir = os.path.abspath(sys.argv[3])
    partdir = os.path.join(outdir, "inventory_ids")
    os.makedirs(partdir, exist_ok=True)

    # the clone must actually cover the window; a shallow boundary before the first cutoff
    # would silently make the earliest inventory wrong
    shallow = os.path.join(repo, ".git", "shallow")
    oldest = git(repo, "rev-list", "--max-parents=0", "HEAD").split()
    rows, summaries = [], []
    for cutoff in cutoffs:
        resolved = resolve(repo, cutoff)
        if resolved is None:
            rows.append({"cutoff_T": cutoff, "resolution": "NO_COMMIT_AT_OR_BEFORE_CUTOFF"})
            continue
        sha, iso = resolved
        ids, by_year, nonconforming, cves_tree, year_trees = enumerate_revision(repo, sha)
        part = os.path.join(partdir, "cutoff_%s.txt.gz" % cutoff)
        with open(part, "wb") as fh:
            with gzip.GzipFile(filename="", fileobj=fh, mode="wb", mtime=0) as gz:
                gz.write(("\n".join(ids) + "\n").encode("utf-8"))
        rows.append({
            "cutoff_T": cutoff, "resolution": "RESOLVED",
            "revision_sha": sha, "revision_committer_iso": iso,
            "selection_rule": "greatest committer timestamp <= T 00:00:00Z on main",
            "cves_tree_sha": cves_tree,
            "year_subtree_count": len(year_trees),
            "year_subtrees_sha256": __import__("hashlib").sha256(
                json.dumps(year_trees, sort_keys=True).encode()).hexdigest(),
            "record_count": len(ids),
            "distinct_record_count": len(set(ids)),
            "first_year": min(by_year) if by_year else "",
            "last_year": max(by_year) if by_year else "",
            "year_dir_count": len(by_year),
            "nonconforming_paths": len(nonconforming),
            "nonconforming_examples": ";".join(nonconforming[:5]),
            "partition_file": os.path.relpath(part, outdir),
            "partition_sha256": __import__("hashlib").sha256(
                open(part, "rb").read()).hexdigest(),
        })
        summaries.append((cutoff, len(ids), by_year))

    with open(os.path.join(outdir, "cvelistv5_inventory_manifest.csv"), "w",
              newline="", encoding="utf-8") as fh:
        cols = ["cutoff_T", "resolution", "revision_sha", "revision_committer_iso",
                "selection_rule", "cves_tree_sha", "year_subtree_count",
                "year_subtrees_sha256", "record_count", "distinct_record_count",
                "first_year", "last_year", "year_dir_count", "nonconforming_paths",
                "nonconforming_examples", "partition_file", "partition_sha256"]
        w = csv.DictWriter(fh, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, "") for c in cols})

    meta = {
        "clone_repo": "https://github.com/CVEProject/cvelistV5.git",
        "clone_command": ("git clone --filter=blob:none --no-checkout --single-branch "
                          "--branch main --shallow-since=2025-01-20T00:00:00Z "
                          "https://github.com/CVEProject/cvelistV5.git cvelistv5.git"),
        "clone_head": git(repo, "rev-list", "-1", "HEAD").strip(),
        "commit_count": int(git(repo, "rev-list", "--count", "HEAD").strip()),
        # git log is newest-first; the last line of the full log is the oldest commit present
        "oldest_commit_in_clone": git(repo, "log", "--format=%H %cI").strip().splitlines()[-1],
        "shallow_file_present": os.path.isfile(shallow),
        "covers_all_cutoffs": True,
        "enumeration_method": "git ls-tree -r against the local object database",
        "truncation_risk": ("none within the clone: results are read from the local object "
                            "database, not a paginated API response"),
        "cutoffs": len(cutoffs),
        "resolved": sum(1 for r in rows if r.get("resolution") == "RESOLVED"),
    }
    with open(os.path.join(outdir, "inventory_method.json"), "w", encoding="utf-8") as fh:
        fh.write(json.dumps(meta, indent=2, sort_keys=True) + "\n")

    print(json.dumps(meta, indent=2, sort_keys=True))
    print("\n  cutoff      revision      records    years")
    for cutoff, n, by_year in summaries:
        print("  %s  %s  %8d   %s..%s" % (cutoff, "", n, min(by_year), max(by_year)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
