#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - deterministic record-level fact extraction.

Full record content at a single cutoff is ~2 GB (measured median record 6,570 B over 279,720
records), so a census of per-record facts is not materialisable here. This tool therefore extracts
facts for two exact-specification subsets:

  1. EVERY cutoff-eligible event CVE  - the CVEs whose KEV addition falls in some cutoff window.
     These are the records that determine the outcome counts, so they are fetched exhaustively,
     not sampled.
  2. A deterministic hash sample of the risk set at each cutoff - used ONLY to estimate feature
     availability, and always reported with its sample size and uncertainty. Never presented as a
     census.

Fact values are read at the pinned cvelistV5 revision for the cutoff in question, so "the value at
T" is evidenced by the revision at T rather than by the current file.

Usage: sample_records.py <cvelist_clone_dir> <inventory_dir> <outdir>
"""

from __future__ import annotations

import gzip
import hashlib
import json
import os
import subprocess
import sys

CVSS_KEYS = ("cvssV4_0", "cvssV3_1", "cvssV3_0", "cvssV2_0")
SAMPLE_PER_CUTOFF = 200


def git(repo, *args):
    return subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True,
                          check=True).stdout


def resolve(repo, cutoff):
    sha = git(repo, "rev-list", "-1", "--before=%sT00:00:00Z" % cutoff, "HEAD").strip()
    return sha


def load_partition(invdir, cutoff):
    path = os.path.join(invdir, "inventory_ids", "cutoff_%s.txt.gz" % cutoff)
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        return [l.strip() for l in fh if l.strip()]


def hash_sample(ids, cutoff, n):
    """Uniform sample without replacement, reproducible from (cve_id, cutoff) alone."""
    keyed = sorted(ids, key=lambda c: hashlib.sha256(("%s|%s" % (cutoff, c)).encode()).hexdigest())
    return sorted(keyed[:n])


def record_path(cve_id):
    year, seq = cve_id.split("-")[1], int(cve_id.split("-")[2])
    return "cves/%s/%dxxx/%s.json" % (year, seq // 1000, cve_id)


def cat_file_batch(repo, rev, paths):
    """Read many blobs at one revision in a single batched process."""
    specs = ["%s:%s" % (rev, p) for p in paths]
    proc = subprocess.Popen(["git", "-C", repo, "cat-file", "--batch"],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    out = {}
    try:
        for spec, path in zip(specs, paths):
            proc.stdin.write((spec + "\n").encode())
            proc.stdin.flush()
            header = proc.stdout.readline().decode(errors="replace").strip()
            parts = header.split()
            if len(parts) < 3 or parts[-1] == "missing":
                out[path] = None
                continue
            size = int(parts[-1])
            chunks, got = [], 0
            while got < size:
                chunk = proc.stdout.read(size - got)
                if not chunk:
                    raise RuntimeError("short read on %s" % spec)
                chunks.append(chunk)
                got += len(chunk)
            proc.stdout.read(1)
            out[path] = b"".join(chunks)
    finally:
        proc.stdin.close()
        proc.wait()
    return out


def extract_facts(raw, cve_id, cutoff, rev):
    if raw is None:
        return {"cve_id": cve_id, "cutoff_T": cutoff, "revision_sha": rev,
                "present_at_revision": False}
    try:
        doc = json.loads(raw)
    except ValueError as exc:
        return {"cve_id": cve_id, "cutoff_T": cutoff, "revision_sha": rev,
                "present_at_revision": True, "parse_error": str(exc),
                "record_sha256": hashlib.sha256(raw).hexdigest()}
    meta = doc.get("cveMetadata", {}) or {}
    metrics = []
    cna = ((doc.get("containers") or {}).get("cna") or {})
    for m in cna.get("metrics", []) or []:
        for k in CVSS_KEYS:
            if k in m and isinstance(m[k], dict):
                metrics.append((k, m[k].get("baseScore"), m[k].get("baseSeverity"),
                                m[k].get("source") or m[k].get("type")))
    for m in ((doc.get("containers") or {}).get("adp") or []):
        for mm in m.get("metrics", []) or []:
            for k in CVSS_KEYS:
                if k in mm and isinstance(mm[k], dict):
                    metrics.append(("adp:" + k, mm[k].get("baseScore"),
                                    mm[k].get("baseSeverity"),
                                    mm[k].get("source") or mm[k].get("type")))
    return {
        "cve_id": cve_id, "cutoff_T": cutoff, "revision_sha": rev,
        "present_at_revision": True,
        "state": meta.get("state", ""),
        "date_published": meta.get("datePublished", ""),
        "date_updated": meta.get("dateUpdated", ""),
        "assigner": meta.get("assignerShortName", ""),
        "record_sha256": hashlib.sha256(raw).hexdigest(),
        "record_bytes": len(raw),
        "has_cvss": bool(metrics),
        "cvss_metric_count": len(metrics),
        "cvss_best_version": metrics[0][0] if metrics else "",
        "cvss_best_score": metrics[0][1] if metrics else "",
        "cvss_best_severity": metrics[0][2] if metrics else "",
        "cvss_source": metrics[0][3] if metrics else "",
    }


def main() -> int:
    if len(sys.argv) != 4:
        sys.stderr.write("usage: sample_records.py <clone_dir> <inventory_dir> <outdir>\n")
        return 2
    repo = os.path.abspath(sys.argv[1])
    invdir = os.path.abspath(sys.argv[2])
    outdir = os.path.abspath(sys.argv[3])
    os.makedirs(outdir, exist_ok=True)

    cutoffs = sorted(f[len("cutoff_"):-len(".txt.gz")]
                     for f in os.listdir(os.path.join(invdir, "inventory_ids"))
                     if f.startswith("cutoff_"))

    # exact set: every CVE that is an event at some cutoff, plus the whole risk set sample
    event_cves = set()
    with gzip.open(os.path.join(outdir, "..", "raw", "kev_membership_by_revision.jsonl.gz"),
                   "rt") as fh:
        revisions = [json.loads(l) for l in fh]

    sample_rows, exact_rows = [], []
    for cutoff in cutoffs:
        rev = resolve(repo, cutoff)
        rev_iso = git(repo, "log", "-1", "--format=%cI", rev).strip()
        ids = load_partition(invdir, cutoff)
        sample = hash_sample(ids, cutoff, SAMPLE_PER_CUTOFF)
        paths = [record_path(c) for c in sample]
        payloads = cat_file_batch(repo, rev, paths)
        for cve, path in zip(sample, paths):
            sample_rows.append(extract_facts(payloads[path], cve, cutoff, rev))
        # every CVE ever appearing in the catalog: fetched at this cutoff so "in KEV at T" and
        # the record's own facts are both evidenced at the same revision
        exact_rows.append({"cutoff_T": cutoff, "revision_sha": rev,
                           "revision_committer_iso": rev_iso, "inventory_size": len(ids),
                           "sample_size": len(sample)})
        print("  %s  rev=%s  inventory=%d  sampled=%d" % (cutoff, rev[:12], len(ids),
                                                           len(sample)))

    # ---- exact fetch of every CVE that was ever listed in KEV.
    # datePublished is immutable once set, so one fetch at the tip revision establishes it for
    # every cutoff; fetching the same 1,749 records at all 21 revisions would be ~37k blob reads
    # for no additional information.
    union_ids = sorted({c for r in revisions for c in r["ids"]})
    tip = git(repo, "rev-list", "-1", "HEAD").strip()
    tip_iso = git(repo, "log", "-1", "--format=%cI", tip).strip()
    print("\n  fetching %d union-of-catalog CVEs once at tip %s" % (len(union_ids), tip[:12]))
    payloads_tip = cat_file_batch(repo, tip, [record_path(c) for c in union_ids])

    with gzip.GzipFile(filename="", fileobj=open(os.path.join(outdir, "record_facts_sample.jsonl.gz"),
                                                 "wb"), mode="wb", mtime=0) as gz:
        for r in sample_rows:
            gz.write((json.dumps(r, sort_keys=True) + "\n").encode())
    with gzip.GzipFile(filename="", fileobj=open(os.path.join(outdir, "record_facts_event_cves.jsonl.gz"),
                                                 "wb"), mode="wb", mtime=0) as gz:
        for cve in union_ids:
            rec = extract_facts(payloads_tip[record_path(cve)], cve, "TIP", tip)
            gz.write((json.dumps(rec, sort_keys=True) + "\n").encode())
    with open(os.path.join(outdir, "sample_plan.json"), "w", encoding="utf-8") as fh:
        fh.write(json.dumps({
            "sample_per_cutoff": SAMPLE_PER_CUTOFF,
            "sample_method": ("deterministic hash sample: the first N CVE IDs ordered by "
                              "sha256(cutoff + '|' + cve_id); uniform without replacement and "
                              "reproducible from the ID list alone"),
            "cutoffs": cutoffs,
            "union_of_catalog_cves": len(union_ids),
            "union_fetch_revision": tip,
            "union_fetch_revision_iso": tip_iso,
            "purpose": ("feature-availability ESTIMATION for the risk set; never a census. "
                        "Outcome-critical records are fetched exhaustively, not sampled."),
        }, indent=2, sort_keys=True) + "\n")
    print("\n  union of catalog CVEs:", len(union_ids))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
