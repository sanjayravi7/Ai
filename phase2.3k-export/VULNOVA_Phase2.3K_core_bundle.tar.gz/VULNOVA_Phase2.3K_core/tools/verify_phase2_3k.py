#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - independent verification of the materialised risk set.

Re-derives the critical counts by routes that do not share code with the builder:

  * inventories come from `git ls-tree` against the pinned store, not from the manifest CSV;
  * KEV membership comes from replaying the catalog revisions, not from the builder's cache;
  * risk-set sizes come from counting the shipped membership partitions, not from the summary;
  * event counts come from the partitions crossed with first-inclusion dates, not from the
    reconciliation CSV.

Where the two disagree the verifier fails. It also checks CSV structural integrity, that the
design constants were not altered, that every membership partition matches its recorded hash, and
that /home/user/Ai is untouched.

Usage: verify_phase2_3k.py <phase_dir> <cvelist_clone_dir> [<ai_repo>]
"""

from __future__ import annotations

import collections
import csv
import datetime as dt
import gzip
import hashlib
import json
import os
import subprocess
import sys

HORIZON_DAYS, MATURITY_LAG_DAYS, TEST_EVENT_GATE = 180, 30, 30
REFERENCE_DATE = "2026-10-15"
D = dt.date.fromisoformat
CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append((name, bool(ok), detail))
    return bool(ok)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def main() -> int:
    if len(sys.argv) < 3:
        sys.stderr.write("usage: verify_phase2_3k.py <phase_dir> <cvelist_clone_dir> "
                         "[<ai_repo>]\n")
        return 2
    phase = os.path.abspath(sys.argv[1])
    repo = os.path.abspath(sys.argv[2])
    ai = os.path.abspath(sys.argv[3]) if len(sys.argv) > 3 else "/home/user/Ai"
    os.chdir(phase)

    # ---------------------------------------------------------------- inputs
    for rel in ("cvelistv5_inventory_manifest.csv", "risk_set_denominator_summary.csv",
                "point_in_time_feature_eligibility.csv", "outcome_and_event_reconciliation.csv",
                "temporal_split_feasibility.csv", "evidence/epss_availability_evidence.csv",
                "raw/kev_timeline_summary.json", "raw/kev_membership_by_revision.jsonl.gz"):
        check("input_present:%s" % rel, os.path.isfile(rel))

    inv = list(csv.DictReader(open("cvelistv5_inventory_manifest.csv", encoding="utf-8")))
    den = list(csv.DictReader(open("risk_set_denominator_summary.csv", encoding="utf-8")))
    out = list(csv.DictReader(open("outcome_and_event_reconciliation.csv", encoding="utf-8")))
    spl = list(csv.DictReader(open("temporal_split_feasibility.csv", encoding="utf-8")))
    epss = list(csv.DictReader(open("evidence/epss_availability_evidence.csv", encoding="utf-8")))
    kevsum = json.load(open("raw/kev_timeline_summary.json", encoding="utf-8"))

    check("cutoffs_21", len(inv) == 21 and len(den) == 21 and len(out) == 21,
          "%d/%d/%d" % (len(inv), len(den), len(out)))

    # ---------------------------------------------------------------- KEV replay
    revisions = []
    with gzip.open("raw/kev_membership_by_revision.jsonl.gz", "rt", encoding="utf-8") as fh:
        for line in fh:
            r = json.loads(line)
            revisions.append((r["commit_date"], set(r["ids"]), r["commit_sha"]))
    revisions.sort(key=lambda x: x[0])
    check("kev_revisions_replayed", len(revisions) == kevsum["readable_revisions"],
          "%d vs %d" % (len(revisions), kevsum["readable_revisions"]))

    def kev_at(cutoff):
        best = None
        for iso, ids, sha in revisions:
            if dt.datetime.fromisoformat(iso.replace("Z", "+00:00")).date().isoformat() < cutoff:
                best = (ids, sha)
            else:
                break
        return best or (set(), "")

    first_seen = {}
    with gzip.open("raw/kev_first_seen.jsonl.gz", "rt", encoding="utf-8") as fh:
        for line in fh:
            r = json.loads(line)
            first_seen[r["cve_id"]] = r["first_observed"][:10]

    check("kev_removals_recorded", kevsum["total_removals"] == 4,
          "got %d" % kevsum["total_removals"])
    check("kev_removal_verdict_not_no_removals",
          kevsum["removal_verdict"] == "REMOVALS_OBSERVED", kevsum["removal_verdict"])
    check("kev_unparseable_revision_recorded", kevsum["unparseable_revision_count"] == 1,
          "got %d" % kevsum["unparseable_revision_count"])

    # ---------------------------------------------------------------- inventory, independent
    indir = "inventory/inventory_ids"
    misfit, partition_bad = [], []
    for row in inv:
        cutoff, rev = row["cutoff_T"], row["revision_sha"]
        path = os.path.join(indir, "cutoff_%s.txt.gz" % cutoff)
        with gzip.open(path, "rt", encoding="utf-8") as fh:
            ids = [l.strip() for l in fh if l.strip()]
        if len(ids) != int(row["record_count"]):
            misfit.append("%s count %d != %s" % (cutoff, len(ids), row["record_count"]))
        # re-derive directly from the store rather than trusting the recorded list
        live = subprocess.run(["git", "-C", repo, "ls-tree", "-r", "--name-only", rev,
                               "--", "cves/"], capture_output=True, text=True).stdout.splitlines()
        live_ids = {p.rsplit("/", 1)[1][:-5] for p in live if p.endswith(".json")
                    and p.rsplit("/", 1)[1].startswith("CVE-")}
        if live_ids != set(ids):
            misfit.append("%s ls-tree mismatch (%d vs %d)" % (cutoff, len(live_ids), len(ids)))
        if sha256_file(path) != row["partition_sha256"]:
            partition_bad.append(cutoff)
    check("inventory_matches_ls_tree", not misfit, ";".join(misfit[:4]))
    check("inventory_partition_hashes_match", not partition_bad, ";".join(partition_bad))

    # ---------------------------------------------------------------- risk set, from partitions
    index = {r["cutoff_T"]: r for r in csv.DictReader(
        open("risk_set_membership/INDEX.csv", encoding="utf-8"))}
    risk_sets, count_bad, hash_bad, reason_bad = {}, [], [], []
    for row in den:
        cutoff = row["cutoff_T"]
        part = "risk_set_membership/cutoff_%s.csv.gz" % cutoff
        with gzip.open(part, "rt", encoding="utf-8") as fh:
            recs = list(csv.DictReader(fh))
        kev_ids, _ = kev_at(cutoff)
        recomputed_risk = {r["cve_id"] for r in recs
                           if r["eligibility_reason_code"] == "ELIGIBLE_AT_RISK"}
        recomputed_kev = {r["cve_id"] for r in recs
                          if r["eligibility_reason_code"] == "EXCLUDED_ALREADY_IN_KEV_AT_T"}
        risk_sets[cutoff] = recomputed_risk
        if len(recomputed_risk) != int(row["risk_set_size"]):
            count_bad.append("%s %d != %s" % (cutoff, len(recomputed_risk), row["risk_set_size"]))
        if recomputed_kev != (set(r["cve_id"] for r in recs) & kev_ids):
            reason_bad.append(cutoff)
        if sha256_file(part) != index[cutoff]["partition_sha256"]:
            hash_bad.append(cutoff)
        # every risk-set member must be a real inventory member
        if not recomputed_risk <= set(r["cve_id"] for r in recs):
            reason_bad.append(cutoff + ":subset")
    check("risk_set_sizes_match_partitions", not count_bad, ";".join(count_bad[:4]))
    check("membership_partition_hashes_match_index", not hash_bad, ";".join(hash_bad))
    check("already_in_kev_flag_matches_kev_replay", not reason_bad, ";".join(reason_bad[:4]))

    # ---------------------------------------------------------------- events, independent
    event_bad, gate_bad = [], []
    for row in out:
        cutoff = row["cutoff_T"]
        lo = D(cutoff)
        hi = lo + dt.timedelta(days=HORIZON_DAYS)
        in_window = {c for c, d in first_seen.items() if lo < D(d) <= hi}
        eligible = in_window & risk_sets[cutoff]
        if len(eligible) != int(row["in_risk_set_at_T"]):
            event_bad.append("%s %d != %s" % (cutoff, len(eligible), row["in_risk_set_at_T"]))
    check("event_counts_match_independent_replay", not event_bad, ";".join(event_bad[:4]))

    check("every_matured_cutoff_meets_gate",
          all(int(r["eligible_events"]) >= TEST_EVENT_GATE
              for r in out if r["matured"] == "YES"),
          "min=%d" % min(int(r["eligible_events"]) for r in out if r["matured"] == "YES"))
    check("censored_cutoffs_never_claim_gate",
          all(r["gate_met"] != "YES" for r in out if r["matured"] == "NO"))
    check("publication_rule_never_violated_by_an_event",
          all(r["publication_rule_satisfied"] == r["in_risk_set_at_T"] for r in out))

    # ---------------------------------------------------------------- split feasibility
    a = [r for r in spl if r["split_id"] == "A_180D_SPACED_3SEG"]
    check("design_A_present_3_segments", len(a) == 3, "got %d" % len(a))
    check("design_A_segments_disjoint",
          all(r["independence_verdict"] == "INDEPENDENT_DISJOINT_EVENT_SETS" for r in a),
          ";".join(r["independence_verdict"] for r in a))
    check("design_A_segments_all_meet_gate", all(r["block_meets_gate"] == "YES" for r in a),
          ";".join("%s=%s" % (r["block"], r["distinct_events"]) for r in a))
    b = [r for r in spl if r["split_id"] == "B_CONTIGUOUS_THIRDS"]
    check("naive_contiguous_split_flagged_not_independent",
          all(r["independence_verdict"] != "INDEPENDENT_DISJOINT_EVENT_SETS" for r in b)
          if b else False,
          ";".join(r["independence_verdict"] for r in b))
    split_blocks = collections.defaultdict(set)
    for r in spl:
        split_blocks[r["split_id"]].add(r["block"])
    # a genuine multi-block design is one whose blocks have a successor decision point;
    # D_ROLLING_ORIGIN is a family of independent single-block probes under one split_id
    multi = {s: b for s, b in split_blocks.items()
             if len(b) >= 3 and any(r["next_block_decision_point"]
                                    for r in spl if r["split_id"] == s)}
    check("no_three_block_split_is_feasible",
          all(all(r["usable_as_historical_split"] == "NO" for r in spl if r["split_id"] == s)
              for s in multi),
          ";".join(sorted(multi)))
    check("design_A_fails_on_label_maturity_not_on_gate",
          all(r["labels_matured_before_next_block"] == "NO" for r in a if r["block"] != "SEG3")
          and all(r["block_meets_gate"] == "YES" for r in a),
          ";".join("%s slack=%s" % (r["block"], r["maturity_slack_days"]) for r in a))
    check("label_maturity_span_is_horizon_plus_lag",
          all(r["label_maturity_date"] == (D(r["cutoffs"].split(";")[-1])
                                           + dt.timedelta(days=210)).isoformat()
              for r in spl if r["cutoffs"]))
    best = [r for r in spl if r["split_id"].startswith("E_LABEL_MATURED_2")]
    check("two_block_design_is_the_ceiling_and_is_feasible",
          bool(best) and all(r["split_verdict"] == "FEASIBLE" for r in best)
          and all(r["block_meets_gate"] == "YES" for r in best),
          ";".join("%s=%s" % (r["block"], r["distinct_events"]) for r in best))
    e3 = [r for r in spl if r["split_id"] == "A2_EARLIEST_3BLOCK"]
    check("earliest_three_block_design_not_yet_matured",
          bool(e3) and e3[-1]["all_cutoffs_matured"] == "NO",
          e3[-1]["label_maturity_date"] if e3 else "absent")
    rol = [r for r in spl if r["split_id"] == "D_ROLLING_ORIGIN"]
    check("rolling_origin_covers_all_matured_cutoffs", len(rol) == 14, "got %d" % len(rol))
    # exact match, not a substring test: "NOT_INDEPENDENT_SHARED_EVENTS" contains "INDEPENDENT"
    check("no_split_declared_independent_on_chronology_alone",
          all((r["independence_verdict"] != "INDEPENDENT_DISJOINT_EVENT_SETS")
              or not r["shares_events_with"] for r in spl),
          ";".join(sorted({r["split_id"] for r in spl
                           if r["independence_verdict"] == "INDEPENDENT_DISJOINT_EVENT_SETS"
                           and r["shares_events_with"]})))

    # ---------------------------------------------------------------- EPSS evidence
    check("epss_backfill_verdicts_present",
          sum(1 for r in epss if r.get("availability_verdict") == "BACKFILLED_AFTER_CUTOFF") == 13,
          str(collections.Counter(r.get("availability_verdict") for r in epss)))
    check("epss_available_only_where_same_day_commit",
          all(r["backfill_lag_days"] == "0" for r in epss
              if r.get("availability_verdict") == "HISTORICALLY_AVAILABLE"))
    check("epss_coverage_only_reported_when_available",
          all(not r.get("epss_coverage_pct") for r in epss
              if r.get("availability_verdict") != "HISTORICALLY_AVAILABLE"))

    # ---------------------------------------------------------------- feature eligibility
    feat = list(csv.DictReader(open("point_in_time_feature_eligibility.csv", encoding="utf-8")))
    check("feature_rows_21", len(feat) == 21, "got %d" % len(feat))
    check("feature_cvss_exact_census",
          all(r["cvss_evidence"] == "EXACT_CENSUS_AT_PINNED_REVISION" for r in feat))
    check("feature_epss_not_claimed_where_backfilled",
          all(r["epss_availability_verdict"] == "HISTORICALLY_AVAILABLE"
              for r in feat if r["epss_evidence"] == "EXACT_FILE_AT_T"))
    check("cvss_coverage_rises_over_time",
          float(feat[0]["cvss_coverage_pct"]) < float(feat[-1]["cvss_coverage_pct"]))

    # ---------------------------------------------------------------- constants + integrity
    check("gate_unchanged_30", TEST_EVENT_GATE == 30)
    check("horizon_unchanged_180", HORIZON_DAYS == 180)
    check("maturity_unchanged_30_plus_180",
          MATURITY_LAG_DAYS == 30 and HORIZON_DAYS + MATURITY_LAG_DAYS == 210)
    for name in ("cvelistv5_inventory_manifest.csv", "risk_set_denominator_summary.csv",
                 "point_in_time_feature_eligibility.csv", "outcome_and_event_reconciliation.csv",
                 "temporal_split_feasibility.csv"):
        with open(name, newline="", encoding="utf-8") as fh:
            rd = csv.reader(fh)
            header = next(rd)
            ragged = [i for i, row in enumerate(rd, start=2) if len(row) != len(header)]
        check("csv_wellformed:%s" % name, not ragged, "ragged %s" % ragged[:4])

    qs_path = "phase2_3k_quality_summary.json"
    if os.path.isfile(qs_path):
        qs = json.load(open(qs_path, encoding="utf-8"))
        check("decision_is_one_of_the_three_allowed",
              qs["decision"] in ("HISTORICAL_EVALUATION_VIABLE", "NOT_VIABLE_HISTORICAL",
                                 "BLOCKED_INSUFFICIENT_EVIDENCE"), qs["decision"])
        # use `multi` (chained, >=3 blocks) -- not split_blocks, which conflates the 14
        # independent single-block probes of D_ROLLING_ORIGIN into one "14-block design"
        no_three_block_split = not any(r["usable_as_historical_split"] == "YES"
                                       for s in multi for r in spl if r["split_id"] == s)
        check("decision_matches_the_split_evidence",
              (qs["decision"] == "NOT_VIABLE_HISTORICAL") == no_three_block_split,
              "decision=%s no_three_block_split=%s" % (qs["decision"], no_three_block_split))
        check("gate_not_relaxed", qs["constants_preserved"]["test_event_gate"] == 30
              and qs["temporal_feasibility"]["gate_relaxed"] is False)
        check("no_model_work_claimed", not any(
            v for k, v in qs["prohibitions_observed"].items()
            if k in ("model_trained", "model_tuned", "predictive_evaluation_run",
                     "protocol_amendment_approved", "confirmatory_no_go_lifted")))
    else:
        check("quality_summary_present", False, "absent")

    man_path = "phase2_3k_integrity_manifest.json"
    if os.path.isfile(man_path):
        man = json.load(open(man_path, encoding="utf-8"))
        bad = []
        for e in man["files"]:
            if not os.path.isfile(e["path"]):
                bad.append(e["path"] + " missing")
            elif sha256_file(e["path"]) != e["sha256"]:
                bad.append(e["path"] + " digest")
        check("integrity_manifest_matches", not bad, ";".join(bad[:4]))
        check("integrity_manifest_excludes_itself",
              all(e["path"] != man_path for e in man["files"]))
    else:
        check("integrity_manifest_present", False, "absent")

    # ---------------------------------------------------------------- repo untouched
    if os.path.isdir(ai):
        head = subprocess.run(["git", "-C", ai, "rev-parse", "HEAD"],
                              capture_output=True, text=True).stdout.strip()
        status = subprocess.run(["git", "-C", ai, "status", "--porcelain"],
                                capture_output=True, text=True).stdout.strip()
        check("Ai_HEAD_unchanged", head == "34750f6bcb069863680e446ed53d23c33a21ae73", head)
        check("Ai_worktree_clean", status == "", status[:100])
    else:
        check("Ai_repo_present", False, "absent")

    failed = [c for c in CHECKS if not c[1]]
    for name, ok, detail in CHECKS:
        if not ok:
            print("FAIL %-54s %s" % (name, detail))
    print("checks=%d passed=%d failed=%d" % (len(CHECKS), len(CHECKS) - len(failed), len(failed)))
    print("overall=%s" % ("PASS" if not failed else "FAIL"))
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
