#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - risk-set materialisation, denominator reconciliation and split feasibility.

Deterministic and offline. Consumes only pinned local evidence:

  inventory/cvelistv5_inventory_manifest.csv   pinned revision per cutoff (build_inventory.py)
  inventory/inventory_ids/cutoff_*.txt.gz      exact record inventory per cutoff
  raw/kev_membership_by_revision.jsonl.gz      exact KEV membership per committed revision
  raw/kev_timeline_summary.json                KEV additions/removals/defects
  <census_dir>/census_*.jsonl.gz               per-record facts at each cutoff's revision

Nothing is estimated. Every count is derived from membership sets and is reproducible from the
inputs above.

Usage: build_phase2_3k.py <census_dir> <outdir>
"""

from __future__ import annotations

import collections
import csv
import datetime as dt
import gzip
import json
import os
import sys

HORIZON_DAYS = 180
MATURITY_LAG_DAYS = 30
TEST_EVENT_GATE = 30
REFERENCE_DATE = "2026-10-15"

D = dt.date.fromisoformat
DTS = lambda s: dt.datetime.fromisoformat(s.replace("Z", "+00:00"))  # noqa: E731


# --------------------------------------------------------------------------- loading


def load_kev(membership_path):
    """(commit_iso_date, set_of_ids, commit_sha) for every readable KEV revision."""
    revs = []
    with gzip.open(membership_path, "rt", encoding="utf-8") as fh:
        for line in fh:
            r = json.loads(line)
            revs.append((r["commit_iso"] if "commit_iso" in r else r["commit_date"],
                         set(r["ids"]), r["commit_sha"]))
    revs.sort(key=lambda x: x[0])
    return revs


def kev_state_at(revs, cutoff):
    """Latest readable revision whose committer instant is <= cutoff 00:00Z."""
    best = None
    for iso, ids, sha in revs:
        d = DTS(iso).date().isoformat()
        if d < cutoff:
            best = (iso, ids, sha)
        else:
            break
    return best


def load_inventory(ids_path):
    with gzip.open(ids_path, "rt", encoding="utf-8") as fh:
        return [l.strip() for l in fh if l.strip()]


def load_census(path):
    facts = {}
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            r = json.loads(line)
            facts[r["cve_id"]] = r
    return facts


# --------------------------------------------------------------------------- classification

REASON_CODES = [
    "ELIGIBLE_AT_RISK",
    "EXCLUDED_ALREADY_IN_KEV_AT_T",
    "EXCLUDED_REJECTED_RECORD",
    "EXCLUDED_UNPUBLISHED_AT_T",
    "EXCLUDED_MALFORMED_IDENTIFIER",
    "UNRESOLVED_RECORD_UNREADABLE",
]


def classify(cve, in_kev_at_t, fact):
    """Return one reason code. Evaluated from state at T only; no future information."""
    if in_kev_at_t:
        return "EXCLUDED_ALREADY_IN_KEV_AT_T"
    if fact is None:
        return "UNRESOLVED_RECORD_UNREADABLE"
    if fact.get("parse_error"):
        return "UNRESOLVED_RECORD_UNREADABLE"
    if fact.get("rejected"):
        return "EXCLUDED_REJECTED_RECORD"
    published = (fact.get("date_published") or "")[:10]
    if not published:
        # a record with no publication date is not demonstrably published at T
        return "EXCLUDED_UNPUBLISHED_AT_T"
    return "ELIGIBLE_AT_RISK"


def main() -> int:
    if len(sys.argv) != 3:
        sys.stderr.write("usage: build_phase2_3k.py <census_dir> <outdir>\n")
        return 2
    census_dir = os.path.abspath(sys.argv[1])
    outdir = os.path.abspath(sys.argv[2])
    os.makedirs(outdir, exist_ok=True)

    inv_rows = list(csv.DictReader(open("inventory/cvelistv5_inventory_manifest.csv",
                                        encoding="utf-8")))
    kev_revs = load_kev("raw/kev_membership_by_revision.jsonl.gz")
    kev_summary = json.load(open("raw/kev_timeline_summary.json", encoding="utf-8"))
    first_seen = {}
    with gzip.open("raw/kev_first_seen.jsonl.gz", "rt", encoding="utf-8") as fh:
        for line in fh:
            r = json.loads(line)
            first_seen[r["cve_id"]] = r["first_observed"][:10]

    ref = D(REFERENCE_DATE)
    cutoffs = [r["cutoff_T"] for r in inv_rows]

    # Only a few thousand CVEs can ever be an event. Retaining full per-cutoff census or
    # risk-set state for all 21 cutoffs would need several GB (it OOM-killed the first run), so
    # the loop below retains state only for these.
    event_universe = set()
    for cutoff in cutoffs:
        lo, hi = D(cutoff), D(cutoff) + dt.timedelta(days=HORIZON_DAYS)
        event_universe |= {c for c, d in first_seen.items() if lo < D(d) <= hi}

    # ------------------------------------------------------------------ per-cutoff population
    denominator_rows, feature_rows, membership_index = [], [], []
    risk_sets, event_facts = {}, {}

    for row in inv_rows:
        cutoff = row["cutoff_T"]
        ids = load_inventory(os.path.join("inventory", "inventory_ids",
                                          "cutoff_%s.txt.gz" % cutoff))
        idset = set(ids)
        census_path = os.path.join(census_dir, "census_%s.jsonl.gz" % cutoff)
        facts = load_census(census_path) if os.path.isfile(census_path) else {}

        state = kev_state_at(kev_revs, cutoff)
        if state is None:
            kev_ids, kev_iso, kev_sha = set(), "", ""
        else:
            kev_iso, kev_ids, kev_sha = state
        kev_at_t = idset & kev_ids
        in_kev_sha = kev_sha

        reasons = collections.Counter()
        risk = []
        for cve in ids:
            code = classify(cve, cve in kev_at_t, facts.get(cve))
            reasons[code] += 1
            if code == "ELIGIBLE_AT_RISK":
                risk.append(cve)
        riskset = set(risk)
        risk_sets[cutoff] = {c for c in event_universe if c in riskset}

        # ---- feature availability, exact, over the risk set only
        with_cvss = sum(1 for c in risk if facts.get(c, {}).get("has_cvss"))
        with_cvss_cna = sum(1 for c in risk if facts.get(c, {}).get("cvss_cna"))
        published_after = sum(1 for c in risk
                              if (facts.get(c, {}).get("date_published") or "")[:10] > cutoff)
        no_features = sum(1 for c in risk if not facts.get(c, {}).get("has_cvss"))
        event_facts[cutoff] = {c: facts[c] for c in event_universe if c in facts}
        matured = (D(cutoff) + dt.timedelta(days=HORIZON_DAYS + MATURITY_LAG_DAYS)) <= ref

        denominator_rows.append({
            "cutoff_T": cutoff,
            "revision_sha": row["revision_sha"],
            "revision_committer_iso": row["revision_committer_iso"],
            "matured": "YES" if matured else "NO",
            "maturity_date": str(D(cutoff) + dt.timedelta(days=HORIZON_DAYS + MATURITY_LAG_DAYS)),
            "inventory_records": len(idset),
            "kev_revision_sha": in_kev_sha,
            "kev_revision_iso": kev_iso,
            "kev_staleness_days": (D(cutoff) - DTS(kev_iso).date()).days if kev_iso else "",
            "kev_entries_at_T": len(kev_ids),
            "cve_in_kev_at_T": len(kev_at_t),
            "excluded_already_in_kev": reasons["EXCLUDED_ALREADY_IN_KEV_AT_T"],
            "excluded_rejected_record": reasons["EXCLUDED_REJECTED_RECORD"],
            "excluded_unpublished_at_T": reasons["EXCLUDED_UNPUBLISHED_AT_T"],
            "excluded_malformed_identifier": reasons["EXCLUDED_MALFORMED_IDENTIFIER"],
            "unresolved_record_unreadable": reasons["UNRESOLVED_RECORD_UNREADABLE"],
            "risk_set_size": len(risk),
            "census_loaded": "YES" if facts else "NO",
            "risk_with_cvss": with_cvss,
            "risk_with_cvss_cna": with_cvss_cna,
            "risk_without_any_cvss": no_features,
            "risk_published_after_T": published_after,
            "cvss_coverage_pct": round(100.0 * with_cvss / len(risk), 2) if risk else "",
        })
        # ---- partitioned membership: one deterministic partition per cutoff, indexable and
        # hashable, so the required dataset is shipped rather than only its counts
        pdir = os.path.join(outdir, "risk_set_membership")
        os.makedirs(pdir, exist_ok=True)
        part_rel = "risk_set_membership/cutoff_%s.csv.gz" % cutoff
        part_abs = os.path.join(outdir, part_rel)
        with gzip.GzipFile(filename="", fileobj=open(part_abs, "wb"), mode="wb", mtime=0) as gz:
            gz.write(b"cve_id,cutoff_T,eligibility_reason_code\n")
            for cve in ids:
                code = classify(cve, cve in kev_at_t, facts.get(cve))
                gz.write(("%s,%s,%s\n" % (cve, cutoff, code)).encode("utf-8"))
        membership_index.append({
            "cutoff_T": cutoff, "risk_set_size": len(risk),
            "records_total": len(idset),
            "partition": part_rel,
            "partition_bytes": os.path.getsize(part_abs),
            "partition_sha256": __import__("hashlib").sha256(
                open(part_abs, "rb").read()).hexdigest(),
            "reason_counts": ";".join("%s=%d" % (k, reasons[k]) for k in sorted(reasons)),
        })

        epss_path = "evidence/epss_availability_evidence.csv"
        epss_verdict, epss_rows_covered = "", ""
        if os.path.isfile(epss_path):
            for e in csv.DictReader(open(epss_path, encoding="utf-8")):
                if e["cutoff_T"] == cutoff:
                    epss_verdict = e.get("availability_verdict", "")
                    epss_rows_covered = e.get("risk_with_epss_score", "")
                    break
        feature_rows.append({
            "cutoff_T": cutoff, "revision_sha": row["revision_sha"],
            "risk_set_size": len(risk),
            "cvss_available_exact": with_cvss,
            "cvss_available_cna_only": with_cvss_cna,
            "cvss_unavailable": no_features,
            "cvss_coverage_pct": round(100.0 * with_cvss / len(risk), 2) if risk else "",
            "cvss_evidence": "EXACT_CENSUS_AT_PINNED_REVISION",
            "epss_availability_verdict": epss_verdict,
            "epss_risk_rows_with_score": epss_rows_covered,
            "epss_evidence": ("EXACT_FILE_AT_T" if epss_verdict == "HISTORICALLY_AVAILABLE"
                              else "NOT_HISTORICALLY_AVAILABLE_AT_T"),
            "state_published": sum(1 for c in risk
                                   if facts.get(c, {}).get("state") == "PUBLISHED"),
            "state_non_published": sum(1 for c in risk
                                       if facts.get(c, {}).get("state") not in ("PUBLISHED", "")),
            "state_missing": sum(1 for c in risk if not facts.get(c, {}).get("state")),
            "date_published_after_T": published_after,
        })
        print("  %s  inv=%7d  kev@T=%5d  risk=%7d  cvss=%6.1f%%" %
              (cutoff, len(idset), len(kev_at_t), len(risk),
               100.0 * with_cvss / len(risk) if risk else 0.0))

    with open("risk_set_denominator_summary.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(denominator_rows[0].keys()), lineterminator="\n")
        w.writeheader()
        w.writerows(denominator_rows)

    # ------------------------------------------------------------------ outcome events
    # an event is a CVE's FIRST observed appearance in the catalog; a later reappearance is not
    # a new event. Membership is taken from revisions, so removals are respected.
    event_rows = []
    for cutoff in cutoffs:
        lo, hi = D(cutoff), D(cutoff) + dt.timedelta(days=HORIZON_DAYS)
        in_window = {c for c, d in first_seen.items() if lo < D(d) <= hi}
        eligible = {c for c in in_window if c in risk_sets[cutoff]}
        facts = event_facts.get(cutoff, {})
        published = {c for c in eligible
                     if (facts.get(c, {}).get("date_published") or "")[:10] <= cutoff
                     and facts.get(c, {}).get("date_published")}
        matured = (D(cutoff) + dt.timedelta(days=HORIZON_DAYS + MATURITY_LAG_DAYS)) <= ref
        event_rows.append({
            "cutoff_T": cutoff, "matured": "YES" if matured else "NO",
            "catalogue_additions_in_window": len(in_window),
            "in_risk_set_at_T": len(eligible),
            "outside_risk_set_already_in_kev": len(in_window) - len(eligible),
            "publication_rule_satisfied": len(published),
            "eligible_events": len(published),
            "event_ids": ";".join(sorted(published)),
            "gate_required": TEST_EVENT_GATE,
            "gate_met": "YES" if (len(published) >= TEST_EVENT_GATE and matured) else "NO",
        })

    # ------------------------------------------------------------------ split feasibility
    matured_cutoffs = [r["cutoff_T"] for r in denominator_rows if r["matured"] == "YES"]
    evidenced = {}
    for cutoff in cutoffs:
        lo, hi = D(cutoff), D(cutoff) + dt.timedelta(days=HORIZON_DAYS)
        evidenced[cutoff] = {c for c, d in first_seen.items()
                             if lo < D(d) <= hi and c in risk_sets[cutoff]}

    matured_union = set().union(*[evidenced[c] for c in matured_cutoffs]) \
        if matured_cutoffs else set()
    split_rows = []
    MATURITY_SPAN = HORIZON_DAYS + MATURITY_LAG_DAYS

    def summarise(split_id, family, assignment, purge_days=0, note=""):
        """One row per block.

        A block is only usable strictly if its cutoffs are matured, its event set clears the
        30-event gate, it shares no target event with another block, and every earlier block's
        labels were matured before this block's decision point. The last condition is the one a
        naive chronological split silently violates.
        """
        blocks = collections.defaultdict(set)
        for cutoff, block in assignment:
            blocks[block] |= evidenced[cutoff]
        first = {b: min(c for c, x in assignment if x == b) for b in blocks}
        last = {b: max(c for c, x in assignment if x == b) for b in blocks}
        order = sorted(blocks, key=lambda b: first[b])
        overlap = {}
        for i in range(len(order)):
            for j in range(i + 1, len(order)):
                shared = blocks[order[i]] & blocks[order[j]]
                if shared:
                    overlap[(order[i], order[j])] = len(shared)
        rows_here = []
        for idx, block in enumerate(order):
            others = {k: v for k, v in overlap.items() if block in k}
            n = len(blocks[block])
            matured_here = all(c in matured_cutoffs for c, x in assignment if x == block)
            if idx + 1 < len(order):
                nxt = order[idx + 1]
                need = D(last[block]) + dt.timedelta(days=MATURITY_SPAN)
                ready = "YES" if need <= D(first[nxt]) else "NO"
                slack = (D(first[nxt]) - need).days
            else:
                ready, slack = "NOT_APPLICABLE", ""
            rows_here.append({
                "split_id": split_id, "design_family": family, "block": block,
                "cutoffs": ";".join(c for c, b in assignment if b == block),
                "n_cutoffs": sum(1 for _, b in assignment if b == block),
                "distinct_events": n,
                "gate_required": TEST_EVENT_GATE,
                "block_meets_gate": "YES" if n >= TEST_EVENT_GATE else "NO",
                "all_cutoffs_matured": "YES" if matured_here else "NO",
                "label_maturity_date": (D(last[block]) + dt.timedelta(days=MATURITY_SPAN)).isoformat(),
                "next_block_decision_point": first[order[idx + 1]] if idx + 1 < len(order) else "",
                "labels_matured_before_next_block": ready,
                "maturity_slack_days": slack,
                "purge_days": purge_days,
                "shares_events_with": ";".join("%s=%d" % (k, v) for k, v in sorted(others.items())),
                "independence_verdict": ("INDEPENDENT_DISJOINT_EVENT_SETS" if not others
                                         else "NOT_INDEPENDENT_SHARED_EVENTS"),
                "note": note,
            })
        # one split-level verdict, repeated on every row
        reasons = []
        if any(r["all_cutoffs_matured"] == "NO" for r in rows_here):
            reasons.append("BLOCK_NOT_MATURED")
        if any(r["shares_events_with"] for r in rows_here):
            reasons.append("SHARED_EVENTS")
        if any(r["labels_matured_before_next_block"] == "NO" for r in rows_here):
            reasons.append("LABELS_NOT_MATURED_BEFORE_NEXT_BLOCK")
        if any(r["block_meets_gate"] == "NO" for r in rows_here):
            reasons.append("BELOW_GATE")
        verdict = "FEASIBLE" if not reasons else "INFEASIBLE_" + "_AND_".join(reasons)
        for r in rows_here:
            r["split_verdict"] = verdict
            r["usable_as_historical_split"] = "YES" if verdict == "FEASIBLE" else "NO"
        split_rows.extend(rows_here)
        return verdict

    # the smallest three-block design on the available cutoff grid: earliest cutoff, then the
    # next cutoff at least one full maturity span later, then again
    probe, cursor = [], None
    for c in cutoffs:
        if cursor is None or D(c) >= cursor:
            probe.append(c)
            cursor = D(c) + dt.timedelta(days=MATURITY_SPAN)
        if len(probe) == 3:
            break
    three_block = {
        "candidate_cutoffs": ";".join(probe),
        "blocks_found": len(probe),
        "final_block_label_maturity": (D(probe[-1]) + dt.timedelta(days=MATURITY_SPAN)).isoformat()
                                      if probe else "",
        "all_blocks_matured_at_reference_date": "NO" if any(
            c not in matured_cutoffs for c in probe) else "YES",
        "shortfall_days": max(0, (D(probe[-1]) + dt.timedelta(days=MATURITY_SPAN)
                                  - D(REFERENCE_DATE)).days) if probe else "",
    }

    # design A: 180 days apart -> disjoint outcome windows, but the blocks do not have their
    # labels matured in sequence, which is what a train/validation/test design requires
    spaced = [c for c in ("2025-02-01", "2025-08-01", "2026-02-01") if c in matured_cutoffs]
    if spaced:
        summarise("A_180D_SPACED_3SEG", "rolling_origin_disjoint",
                  [(c, "SEG%d" % (i + 1)) for i, c in enumerate(spaced)],
                  note="disjoint outcome windows; check label maturity ordering")

    # design A2: the earliest 3-block design the cutoff grid can carry, if it ever matures
    if len(probe) == 3:
        summarise("A2_EARLIEST_3BLOCK", "disjoint_sequential",
                  [(c, "BLOCK%d" % (i + 1)) for i, c in enumerate(probe)],
                  note="earliest cutoffs one maturity span apart; %d-day shortfall"
                       % three_block["shortfall_days"])

    # design B: contiguous thirds - the naive chronological split
    if len(matured_cutoffs) >= 6:
        third = len(matured_cutoffs) // 3
        summarise("B_CONTIGUOUS_THIRDS", "contiguous_chronological",
                  [(c, "TRAIN") for c in matured_cutoffs[:third]] +
                  [(c, "VALIDATION") for c in matured_cutoffs[third:2 * third]] +
                  [(c, "TEST") for c in matured_cutoffs[2 * third:]],
                  note="naive split; adjacent windows overlap")

    # design E: the largest design that genuinely has labels matured in sequence
    seq, cursor = [], None
    for c in matured_cutoffs:
        if cursor is None or D(c) >= cursor:
            seq.append(c)
            cursor = D(c) + dt.timedelta(days=MATURITY_SPAN)
    for n in (3, 2):
        if len(seq) >= n:
            summarise("E_LABEL_MATURED_%dBLOCK" % n, "disjoint_sequential",
                      [(c, "BLOCK%d" % (i + 1)) for i, c in enumerate(seq[:n])],
                      note="largest matured-in-sequence design; %d blocks available" % len(seq))

    # design C: single mature test point
    summarise("C_SINGLE_FINAL_CUTOFF", "single_point",
              [(matured_cutoffs[-1], "TEST")])

    # design D: rolling-origin, each matured cutoff used as a test point in turn
    for i, c in enumerate(matured_cutoffs):
        summarise("D_ROLLING_ORIGIN", "rolling_origin",
                  [(c, "TEST%d" % (i + 1))])

    with open("temporal_split_feasibility.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(split_rows[0].keys()), lineterminator="\n")
        w.writeheader()
        w.writerows(split_rows)

    with open("outcome_and_event_reconciliation.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(event_rows[0].keys()) + ["all_matured_distinct_events",
                                                                       "all_matured_rows"],
                           lineterminator="\n")
        w.writeheader()
        union_all = set().union(*evidenced.values()) if evidenced else set()
        for r in event_rows:
            r2 = dict(r)
            r2["all_matured_distinct_events"] = len(matured_union)
            r2["all_matured_rows"] = sum(len(evidenced[c]) for c in matured_cutoffs)
            w.writerow(r2)

    with open("point_in_time_feature_eligibility.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(feature_rows[0].keys()), lineterminator="\n")
        w.writeheader()
        w.writerows(feature_rows)

    with open(os.path.join(outdir, "risk_set_membership", "INDEX.csv"), "w", newline="",
              encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(membership_index[0].keys()), lineterminator="\n")
        w.writeheader()
        w.writerows(membership_index)

    with open("_facts_3k.json", "w", encoding="utf-8") as fh:
        json.dump({
            "cutoffs": len(cutoffs),
            "matured_cutoffs": len(matured_cutoffs),
            "risk_set_min": min(r["risk_set_size"] for r in denominator_rows),
            "risk_set_max": max(r["risk_set_size"] for r in denominator_rows),
            "risk_set_sum_unique_pairs": sum(r["risk_set_size"] for r in denominator_rows),
            "distinct_events_all_matured": len(matured_union),
            "distinct_events_all_cutoffs": len(set().union(*evidenced.values())) if evidenced else 0,
            "kev_additions_total": kev_summary["total_additions"],
            "kev_removals_total": kev_summary["total_removals"],
            "kev_distinct_ever_listed": kev_summary["distinct_cves_ever_listed"],
            "kev_unparseable_revisions": kev_summary["unparseable_revision_count"],
            "split_candidates": len(split_rows),
        }, fh, indent=2, sort_keys=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
