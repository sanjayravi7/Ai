#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - self-contained export packer.

Packs the Phase 2.3K workspace into one deterministic .tar.gz with a SHA-256 manifest of every
member, so the phase can be re-verified from the archive alone.

Determinism: members are sorted, mtimes are zero, gzip mtime is zero, uid/gid are zero, and the
gzip member carries no FNAME. Two runs over an unchanged tree produce a byte-identical archive.

The 21 risk-set membership partitions ARE included. They total ~18 MB and are the required
dataset rather than a count of it, so they ship with the archive; the 406 MB of staged census
fact files are not included and are regenerated instead (~47 s per cutoff).

Usage: build_export_phase2_3k.py <phase_dir> <archive_path>
"""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
import sys
import tarfile

ARCHIVE_PREFIX = "VULNOVA_Phase2.3K"  # also the member root
EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".git"}
EXCLUDE_SUFFIXES = (".pyc", ".tar.gz", ".sha256")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def walk(root):
    out = []
    for base, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDE_DIRS)
        for name in sorted(files):
            if name.endswith(EXCLUDE_SUFFIXES):
                continue
            out.append(os.path.relpath(os.path.join(base, name), root))
    return sorted(out)


def add_bytes(tar, name, payload):
    info = tarfile.TarInfo(name)
    info.size = len(payload)
    info.mtime = 0
    info.mode = 0o644
    info.uid = info.gid = 0
    info.uname = info.gname = "root"
    tar.addfile(info, io.BytesIO(payload))


README = """VULNOVA Phase 2.3K - Point-in-Time Risk-Set Materialization and Temporal Feasibility
=====================================================================================

Contents
--------
  phase2_3k/     the working tree: deliverables, tools, inventory, evidence, raw, membership
  EXPORT_MANIFEST.json
                 path / bytes / sha256 for every member, written before the archive was closed

Start here
----------
  1. VULNOVA_Phase2.3K_Risk_Set_and_Feasibility_Report.md   - findings and the single decision
  2. phase2_3k_quality_summary.json                          - machine-readable result
  3. risk_set_membership/README_partition_scheme.md          - the partition + index scheme
  4. risk_set_denominator_summary.csv                        - exact denominators per cutoff
  5. temporal_split_feasibility.csv                          - per-block event counts and independence

Re-verification
---------------
  cd phase2_3k
  sha256sum -c <(python3 -c "import json;[print(f['sha256'], f['path']) for f in json.load(open('phase2_3k_integrity_manifest.json'))['files']]")

  # independent re-derivation of the critical counts (needs a cvelistV5 clone, ~177 MB):
  python3 tools/verify_phase2_3k.py . <cvelistv5_clone> [<ai_repo>]

The censuses that back the per-cutoff facts are NOT in this archive: 406 MB. Regenerate any
cutoff with:
  curl -sL https://codeload.github.com/CVEProject/cvelistV5/tar.gz/<revision_sha> \\
    | python3 tools/census_from_tarball.py <cutoff_T> <expected_count> <out.jsonl.gz>
(~47 s per cutoff; the revision and expected count are in cvelistv5_inventory_manifest.csv.)

Scope
-----
Data engineering and research validation only. No model was trained, tuned or evaluated, and no
protocol amendment was approved. The standing NO-GO for confirmatory predictive evaluation is
retained.
"""


def main() -> int:
    if len(sys.argv) < 3:
        sys.stderr.write("usage: build_export_phase2_3k.py <phase_dir> <archive_path>\n")
        return 2
    phase = os.path.abspath(sys.argv[1])
    out = os.path.abspath(sys.argv[2])
    os.chdir(phase)

    members = walk(".")
    # the location record describes the archive, so it cannot live inside it
    members = [m for m in members
               if m != os.path.basename(out) and m != "export_location.json"]

    stream = [("README_EXPORT.txt", README.encode())]
    for rel in members:
        with open(rel, "rb") as fh:
            stream.append(("phase2_3k/" + rel, fh.read()))

    payloads = [{"path": n, "bytes": len(p), "sha256": sha256_bytes(p)} for n, p in stream]
    manifest = {
        "phase": "2.3K",
        "archive_prefix": ARCHIVE_PREFIX,
        "member_root": ARCHIVE_PREFIX,
        # the archive carries this manifest as a member, so the true member count is len+1 and
        # the manifest does not list its own digest
        "member_count": len(stream) + 1,
        "members_listed": len(payloads),
        "manifest_self_included": True,
        "manifest_self_digest": "SELF_EXCLUDED",
        "total_bytes": sum(len(p) for _, p in stream),
        "members": payloads,
    }
    stream.insert(1, ("EXPORT_MANIFEST.json",
                      (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()))

    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w") as tar:
        for name, payload in stream:
            add_bytes(tar, ARCHIVE_PREFIX + "/" + name, payload)
    tar_bytes = raw.getvalue()

    gz = io.BytesIO()
    with gzip.GzipFile(filename="", fileobj=gz, mode="wb", mtime=0) as fh:
        fh.write(tar_bytes)

    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    with open(out, "wb") as fh:
        fh.write(gz.getvalue())
    digest = sha256_bytes(gz.getvalue())
    with open(out + ".sha256", "w", encoding="utf-8") as fh:
        fh.write("%s  %s\n" % (digest, os.path.basename(out)))

    # where the archive lives and whether it survives the disposable working directory
    location = {
        "phase": "2.3K",
        "archive_path": out,
        "archive_bytes": len(gz.getvalue()),
        "archive_sha256": digest,
        "sha256_sidecar": out + ".sha256",
        "members": len(stream),
        "uncompressed_tar_bytes": len(tar_bytes),
        "located_under_home": out.startswith(os.path.expanduser("~") + os.sep),
        "persistence": {
            "workspace_root": "/home/user",
            "snapshotted": True,
            "note": (
                "/home/user is snapshotted, so this archive persists with the workspace. The 406 "
                "MB of staged per-cutoff census fact files under /tmp/v23k_census are NOT "
                "snapshotted and are regenerated with tools/census_from_tarball.py (~47 s per "
                "cutoff) from the revisions pinned in cvelistv5_inventory_manifest.csv."
            ),
        },
        "excluded_from_archive": True,
        "reproduce": "python3 tools/build_export_phase2_3k.py . <archive_path>",
    }
    with open("export_location.json", "w", encoding="utf-8") as fh:
        json.dump(location, fh, indent=2, sort_keys=True)
        fh.write("\n")

    print("archive : %s" % out)
    print("bytes   : %d" % len(gz.getvalue()))
    print("sha256  : %s" % digest)
    print("members : %d" % len(stream))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
