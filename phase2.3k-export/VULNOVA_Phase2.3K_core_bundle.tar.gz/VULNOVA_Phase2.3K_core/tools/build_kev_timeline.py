#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - KEV catalog timeline from the official cisagov/kev-data repository.

Builds, from Git history alone, the exact KEV membership at every committed revision, then
detects additions and removals between consecutive revisions. This is what allows a defensible
statement about whether reconstructing "in KEV at T" from the dateAdded field is sound.

Why this exists: the reference snapshot has a dateAdded for every entry, so membership at T is
reconstructible as {dateAdded <= T} *provided nothing was ever removed*. That proviso is an
empirical claim about history, not an assumption, so it is tested here against every revision the
repository ever published.

Reads a blobless clone. Fetches blobs on demand through `git cat-file --batch`, streaming, so peak
memory stays proportional to the distinct entry sets rather than to the catalog bytes.

Usage: build_kev_timeline.py <kev_clone_dir> <outdir>
"""

from __future__ import annotations

import gzip
import json
import os
import subprocess
import sys

CATALOG_PATH = "known_exploited_vulnerabilities.json"


def git(repo, *args, check=True):
    return subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True,
                          check=check).stdout


def revisions(repo):
    """(commit_sha, commit_iso, blob_sha) for every commit that changed the catalog."""
    shas = git(repo, "rev-list", "HEAD", "--", CATALOG_PATH).split()
    out = []
    for c in shas:
        iso = git(repo, "log", "-1", "--format=%cI", c).strip()
        blob = git(repo, "rev-parse", "%s:%s" % (c, CATALOG_PATH)).strip()
        out.append((c, iso, blob))
    out.sort(key=lambda r: r[1])
    return out


def fetch_blobs(repo, blob_shas):
    """Stream every requested blob through a single cat-file batch process."""
    proc = subprocess.Popen(["git", "-C", repo, "cat-file", "--batch"],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    payloads = {}
    try:
        for sha in blob_shas:
            proc.stdin.write((sha + "\n").encode())
            proc.stdin.flush()
            header = proc.stdout.readline().decode().strip().split()
            if len(header) != 3 or header[1] != "blob":
                raise RuntimeError("unexpected cat-file header for %s: %r" % (sha, header))
            size = int(header[2])
            # pipe reads may return short: read until the declared length arrives
            chunks, got = [], 0
            while got < size:
                chunk = proc.stdout.read(size - got)
                if not chunk:
                    raise RuntimeError("short read on %s: %d of %d bytes" % (sha, got, size))
                chunks.append(chunk)
                got += len(chunk)
            payloads[sha] = b"".join(chunks)
            proc.stdout.read(1)  # trailing newline
    finally:
        proc.stdin.close()
        proc.wait()
    return payloads


def main() -> int:
    if len(sys.argv) != 3:
        sys.stderr.write("usage: build_kev_timeline.py <kev_clone_dir> <outdir>\n")
        return 2
    repo = os.path.abspath(sys.argv[1])
    outdir = os.path.abspath(sys.argv[2])
    os.makedirs(outdir, exist_ok=True)

    revs = revisions(repo)
    unique_blobs = sorted({b for _, _, b in revs})
    payloads = fetch_blobs(repo, unique_blobs)

    # ---- parse each distinct catalog version once.
    # A revision that does not parse is recorded as a source-history defect, not skipped: the
    # official mirror published one truncated catalog (commit 15200f913fd2, 2025-02-25).
    parsed, unparseable = {}, {}
    for blob, raw in payloads.items():
        try:
            doc = json.loads(raw)
        except ValueError as exc:
            unparseable[blob] = {"bytes": len(raw), "error": str(exc),
                                 "sha256": __import__("hashlib").sha256(raw).hexdigest(),
                                 "head": raw[:120].decode("utf-8", "replace")}
            continue
        entries = doc.get("vulnerabilities", [])
        parsed[blob] = {
            "ids": sorted(v["cveID"] for v in entries),
            "catalog_version": doc.get("catalogVersion", ""),
            "date_released": doc.get("dateReleased", ""),
            "count": doc.get("count", len(entries)),
            "max_date_added": max((v.get("dateAdded", "") for v in entries), default=""),
            "sha256": __import__("hashlib").sha256(raw).hexdigest(),
        }

    # ---- walk revisions in time order, recording deltas and any removal
    rows = []
    removals = []
    prev_ids = None
    prev_iso = None
    corrupt_revisions = []
    for commit, iso, blob in revs:
        if blob not in parsed:
            # state at this revision is unreadable; do not infer it, and do not reset the
            # running baseline, so the next good revision is compared against the last good one
            corrupt_revisions.append({"commit": commit, "commit_date": iso, "blob_sha": blob,
                                      **unparseable[blob]})
            continue
        info = parsed[blob]
        ids = set(info["ids"])
        if prev_ids is None:
            added, removed = [], []
        else:
            added = sorted(ids - prev_ids)
            removed = sorted(prev_ids - ids)
            for cve in removed:
                removals.append({"commit": commit, "commit_date": iso,
                                 "cve_id": cve, "previous_revision_date": prev_iso})
        rows.append({
            "commit_sha": commit, "commit_date": iso, "blob_sha": blob,
            "content_sha256": info["sha256"], "entry_count": info["count"],
            "parsed_entry_count": len(ids), "catalog_version": info["catalog_version"],
            "date_released": info["date_released"], "max_date_added": info["max_date_added"],
            "added_since_previous": len(added), "removed_since_previous": len(removed),
        })
        prev_ids, prev_iso = ids, iso

    # ---- membership at each committed revision, compressed
    mem_path = os.path.join(outdir, "kev_membership_by_revision.jsonl.gz")
    with open(mem_path, "wb") as fh:
        # GzipFile (not gzip.open) so mtime and the FNAME field can be pinned to zero,
        # which keeps the output byte-identical across runs
        with gzip.GzipFile(filename="", fileobj=fh, mode="wb", mtime=0) as gz:
            for row in rows:
                rec = {"commit_sha": row["commit_sha"], "commit_date": row["commit_date"],
                       "ids": parsed[row["blob_sha"]]["ids"]}
                gz.write((json.dumps(rec, sort_keys=True) + "\n").encode("utf-8"))

    # ---- union of every CVE ever observed, with first appearance
    first_seen = {}
    for row in rows:
        for cve in parsed[row["blob_sha"]]["ids"]:
            first_seen.setdefault(cve, row["commit_date"])
    summary = {
        "catalog_path": CATALOG_PATH,
        "revisions": len(rows),
        "unique_catalog_blobs": len(unique_blobs),
        "first_revision": rows[0]["commit_date"] if rows else None,
        "last_revision": rows[-1]["commit_date"] if rows else None,
        "first_entry_count": rows[0]["entry_count"] if rows else 0,
        "last_entry_count": rows[-1]["entry_count"] if rows else 0,
        "total_additions": sum(r["added_since_previous"] for r in rows),
        "total_removals": sum(r["removed_since_previous"] for r in rows),
        "distinct_cves_ever_listed": len(first_seen),
        "commit_days_span": None,
        "removals": removals,
        "unparseable_revisions": corrupt_revisions,
        "unparseable_revision_count": len(corrupt_revisions),
        "readable_revisions": len(rows),
        "removal_verdict": ("NO_REMOVALS_OBSERVED_IN_HISTORY" if not removals
                            else "REMOVALS_OBSERVED"),
    }
    with open(os.path.join(outdir, "kev_timeline_summary.json"), "w", encoding="utf-8") as fh:
        fh.write(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    with open(os.path.join(outdir, "kev_revisions.csv"), "w", encoding="utf-8") as fh:
        cols = list(rows[0].keys())
        fh.write(",".join(cols) + "\n")
        for r in rows:
            fh.write(",".join(str(r[c]) for c in cols) + "\n")
    with open(os.path.join(outdir, "kev_first_seen.jsonl.gz"), "wb") as fh:
        with gzip.GzipFile(filename="", fileobj=fh, mode="wb", mtime=0) as gz:
            for cve in sorted(first_seen):
                gz.write((json.dumps({"cve_id": cve, "first_observed": first_seen[cve]},
                                     sort_keys=True) + "\n").encode("utf-8"))

    print(json.dumps(summary, indent=2, sort_keys=True)[:1400])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
