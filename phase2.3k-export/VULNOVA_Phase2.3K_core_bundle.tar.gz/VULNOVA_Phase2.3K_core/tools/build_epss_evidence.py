#!/usr/bin/env python3
"""
VULNOVA Phase 2.3K - point-in-time EPSS availability evidence.

Answers one question per cutoff: was the EPSS file whose score date is <= T actually *available*
at T, or was it published later and merely carries an earlier date?

The distinction is not academic. In this repository, 1,746 of 2,003 daily files were committed
long after the date in their filename - the archive was created on 2026-02-02 and backfilled. A
file that says 2021-04-14 was committed on 2026-02-03. Treating its score date as evidence of
availability at a 2021 cutoff would be exactly the substitution the protocol forbids.

Evidence used: the commit that ADDED each file, from Git history. A file earns
HISTORICALLY_AVAILABLE only when its add-commit falls on or before the cutoff.

For cutoffs that do earn it, the file is read and scored coverage over that cutoff's risk set is
counted exactly.

Usage: build_epss_evidence.py <epss_clone_dir> <outdir> [risk_set_membership_dir]
"""

from __future__ import annotations

import csv
import datetime as dt
import gzip
import io
import json
import os
import re
import subprocess
import sys

FILE_RE = re.compile(r"epss_scores-(\d{4}-\d{2}-\d{2})\.csv\.gz$")
D = dt.date.fromisoformat


def git_added(repo):
    """score_date -> (commit_sha, commit_iso) for the commit that added each daily file."""
    out = subprocess.run(["git", "-C", repo, "log", "--diff-filter=A", "--name-only",
                          "--format=@@%H|%cI", "--", "*.csv.gz"],
                         capture_output=True, text=True, check=True).stdout
    added, commit = {}, None
    for line in out.split("\n"):
        if line.startswith("@@"):
            sha, iso = line[2:].split("|")
            commit = (sha, iso)
        else:
            m = FILE_RE.search(line)
            if m and commit:
                # the daily files live under <year>/, so the full path is needed to read them
                added[m.group(1)] = (commit[0], commit[1], line.strip())
    return added


def read_blob(repo, rev, path):
    raw = subprocess.run(["git", "-C", repo, "cat-file", "blob", "%s:%s" % (rev, path)],
                         capture_output=True).stdout
    with gzip.GzipFile(fileobj=io.BytesIO(raw)) as gz:
        return gz.read().decode("utf-8", "replace")


def parse_epss(text):
    """Return (model_version, score_date, {cve: (score, percentile)})."""
    model, score_date, scores = "", "", {}
    for line in text.split("\n"):
        if line.startswith("#"):
            for part in line.lstrip("# ").split(","):
                part = part.strip()
                if part.startswith("model_version:"):
                    model = part.split(":", 1)[1].strip()
                elif part.startswith("score_date:"):
                    score_date = part.split(":", 1)[1].strip()
            continue
        parts = line.split(",")
        if len(parts) >= 3 and parts[0].startswith("CVE-"):
            scores[parts[0]] = (parts[1], parts[2])
    return model, score_date, scores


def main() -> int:
    if len(sys.argv) < 3:
        sys.stderr.write("usage: build_epss_evidence.py <epss_clone_dir> <outdir> "
                         "[risk_set_membership_dir]\n")
        return 2
    repo = os.path.abspath(sys.argv[1])
    outdir = os.path.abspath(sys.argv[2])
    memb = os.path.abspath(sys.argv[3]) if len(sys.argv) > 3 else None
    os.makedirs(outdir, exist_ok=True)

    added = git_added(repo)
    files = sorted(added)
    cutoffs = [l.strip() for l in open("cutoffs.txt") if l.strip()]

    rows = []
    for cutoff in cutoffs:
        eligible = [f for f in files if f <= cutoff]
        if not eligible:
            rows.append({"cutoff_T": cutoff, "available": "NO_FILE_BEFORE_CUTOFF"})
            continue
        score_date = eligible[-1]
        sha, iso, relpath = added[score_date]
        committed = iso[:10]
        lag = (D(committed) - D(score_date)).days
        if committed <= cutoff:
            verdict, available = "HISTORICALLY_AVAILABLE", "YES"
        else:
            verdict, available = "BACKFILLED_AFTER_CUTOFF", "NO"

        row = {
            "cutoff_T": cutoff, "epss_file": "epss_scores-%s.csv.gz" % score_date,
            "epss_score_date": score_date, "file_add_commit_sha": sha,
            "file_add_commit_iso": iso, "backfill_lag_days": lag,
            "availability_verdict": verdict, "eligible_at_T": available,
            "source": "github.com/empiricalsec/epss_scores", "repository_path": relpath,
        }
        # exact coverage over the risk set, only where the file is genuinely contemporaneous
        if available == "YES" and memb:
            part = os.path.join(memb, "cutoff_%s.csv.gz" % cutoff)
            if os.path.isfile(part):
                with gzip.open(part, "rt", encoding="utf-8") as fh:
                    risk = [r["cve_id"] for r in csv.DictReader(fh)
                            if r["eligibility_reason_code"] == "ELIGIBLE_AT_RISK"]
                text = read_blob(repo, sha, relpath)
                model, sd, scores = parse_epss(text)
                covered = sum(1 for c in risk if c in scores)
                if not scores:
                    sys.stderr.write("REFUSING: %s parsed to zero EPSS scores; "
                                     "treating as read failure\n" % score_date)
                    raise SystemExit(3)
                row.update({
                    "epss_model_version": model, "epss_header_score_date": sd,
                    "risk_set_size": len(risk), "risk_with_epss_score": covered,
                    "epss_coverage_pct": round(100.0 * covered / len(risk), 2) if risk else "",
                })
        rows.append(row)
        print("  %s  %s  lag=%dd  %s" % (cutoff, score_date, lag, verdict))

    cols = sorted({k for r in rows for k in r})
    with open(os.path.join(outdir, "epss_availability_evidence.csv"), "w", newline="",
              encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        for r in rows:
            w.writerow(r)

    summary = {
        "daily_files": len(files),
        "file_range": [files[0], files[-1]] if files else [],
        "same_day_committed_files": sum(1 for f in files if added[f][1][:10] == f),
        "backfilled_files": sum(1 for f in files if added[f][1][:10] != f),
        "first_same_day_evidence": min((f for f in files if added[f][1][:10] == f), default=""),
        "cutoffs_historically_available": sum(1 for r in rows
                                              if r.get("eligible_at_T") == "YES"),
        "cutoffs_backfilled_only": sum(1 for r in rows
                                       if r.get("availability_verdict") == "BACKFILLED_AFTER_CUTOFF"),
        "cutoffs_total": len(rows),
    }
    with open(os.path.join(outdir, "epss_evidence_summary.json"), "w", encoding="utf-8") as fh:
        fh.write(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
