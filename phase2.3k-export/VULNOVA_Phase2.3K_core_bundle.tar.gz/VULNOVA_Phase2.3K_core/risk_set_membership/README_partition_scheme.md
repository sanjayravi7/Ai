# Risk-set membership partition scheme (Phase 2.3K)

`risk_set_membership.csv.gz` is too large to ship as a single file while remaining reviewable, so
the required dataset is shipped as **21 deterministic per-cutoff partitions plus an index that
carries the integrity hashes**. This is a storage layout only: the dataset is complete, every
row is present, and nothing is replaced by a count.

## Layout

| File | Contents |
|---|---|
| `cutoff_<T>.csv.gz` | every record in the verified inventory at cutoff `T`, one row per `(CVE, cutoff)` pair |
| `INDEX.csv` | one row per cutoff: partition size, record total, risk-set size, reason counts, `sha256` of the partition |

## Row schema

| Column | Meaning |
|---|---|
| `cve_id` | the exact identifier as it appears in the pinned revision |
| `cutoff_T` | the cutoff date this row belongs to |
| `eligibility_reason_code` | why the record is in the risk set or excluded from it |

## Reason codes

| Code | Meaning |
|---|---|
| `ELIGIBLE_AT_RISK` | in the verified inventory at `T`, satisfies the identifier/publication rules, and not in KEV at `T` |
| `EXCLUDED_ALREADY_IN_KEV_AT_T` | present in the KEV catalog as observed at `T` |
| `EXCLUDED_UNPUBLISHED_AT_T` | present in the revision tree but `datePublished` is absent or after `T` |
| `EXCLUDED_REJECTED_RECORD` | the record is marked rejected in the revision |
| `EXCLUDED_MALFORMED_IDENTIFIER` | the path does not yield a well-formed CVE identifier |
| `UNRESOLVED_RECORD_UNREADABLE` | the record could not be reduced to facts in the census stream |

Rows are ordered by `cve_id` within each partition, so any partition can be regenerated and
compared byte-for-byte.

## Guarantees

* Every partition covers the **full** inventory at its cutoff: the row count equals the record
  count proven complete by `cvelistv5_inventory_manifest.csv` and re-derived from `git ls-tree`
  against the pinned revision by `tools/verify_phase2_3k.py`.
* The risk-set size for a cutoff is the count of rows with `ELIGIBLE_AT_RISK` — a count that can
  be recomputed from the partition alone, without trusting any summary table.
* Each partition's `sha256` is recorded in `INDEX.csv` and in
  `phase2_3k_integrity_manifest.json`.
* A CVE newly published after an earlier cutoff appears **only** in later partitions; earlier
  partitions are never retroactively rewritten.
