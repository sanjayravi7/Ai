VULNOVA Phase 2.3K - Point-in-Time Risk-Set Materialization and Temporal Feasibility
=====================================================================================

Contents
--------
  phase2_3k/     the working tree: deliverables, tools, inventory, evidence, raw, membership
  EXPORT_MANIFEST.json
                 path / bytes / sha256 for every member, written before the archive was closed

Start here
----------
  1. VULNOVA_Phase2.3K_Risk_Set_and_Feasibility_Report.md   - findings and the single decision
  2. phase2_3k_quality_summary.json                          - machine-readable result
  3. risk_set_membership/README_partition_scheme.md          - the partition + index scheme
  4. risk_set_denominator_summary.csv                        - exact denominators per cutoff
  5. temporal_split_feasibility.csv                          - per-block event counts and independence

Re-verification
---------------
  cd phase2_3k
  sha256sum -c <(python3 -c "import json;[print(f['sha256'], f['path']) for f in json.load(open('phase2_3k_integrity_manifest.json'))['files']]")

  # independent re-derivation of the critical counts (needs a cvelistV5 clone, ~177 MB):
  python3 tools/verify_phase2_3k.py . <cvelistv5_clone> [<ai_repo>]

The censuses that back the per-cutoff facts are NOT in this archive: 406 MB. Regenerate any
cutoff with:
  curl -sL https://codeload.github.com/CVEProject/cvelistV5/tar.gz/<revision_sha> \
    | python3 tools/census_from_tarball.py <cutoff_T> <expected_count> <out.jsonl.gz>
(~47 s per cutoff; the revision and expected count are in cvelistv5_inventory_manifest.csv.)

Scope
-----
Data engineering and research validation only. No model was trained, tuned or evaluated, and no
protocol amendment was approved. The standing NO-GO for confirmatory predictive evaluation is
retained.
